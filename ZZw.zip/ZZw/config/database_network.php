<?php
// Network Database configuration for multi-PC access
// This file allows the application to work on multiple PCs on the same network

// Get the server's IP address automatically
function getServerIP() {
    // Try to get the local IP address
    $ip = gethostbyname(gethostname());
    
    // If we get localhost, try alternative method
    if ($ip === '127.0.0.1' || $ip === gethostname()) {
        $connection = @fsockopen('8.8.8.8', 53, $errno, $errstr, 1);
        if ($connection) {
            $ip = stream_socket_get_name($connection, true);
            $ip = substr($ip, 0, strrpos($ip, ':'));
            fclose($connection);
        }
    }
    
    return $ip;
}

// Database configuration
$host = 'localhost'; // Keep as localhost for the main server
$dbname = 'abdelmoula_camp';
$username = 'root';
$password = '';

// For network access, you might need to create a specific user
// Uncomment and modify the following lines if you want to use a network-specific user
/*
$host = getServerIP(); // Use the server's IP address
$username = 'camp_user'; // Create this user in MySQL
$password = 'your_secure_password'; // Use a strong password
*/

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

// Function to get the current server URL for network access
function getServerURL() {
    $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'];
    $path = dirname($_SERVER['SCRIPT_NAME']);
    
    return $protocol . '://' . $host . $path;
}

// Function to get the server IP for network access
function getNetworkURL() {
    $serverIP = getServerIP();
    $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
    $path = dirname($_SERVER['SCRIPT_NAME']);
    
    return $protocol . '://' . $serverIP . $path;
}
?>
