<?php
// Database configuration
$host = 'localhost';
$dbname = 'abdelmoula_camp';
$username = 'root';
$password = 'abdelmoula134';

// Network configuration - uncomment the following lines for network access
// $host = '192.168.1.100'; // Replace with your actual IP address
// $username = 'camp_network_user'; // Use network user if created
// $password = 'your_secure_password'; // Use network user password

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

// Function to get server IP for network access
function getServerIP() {
    $ip = gethostbyname(gethostname());
    if ($ip === '127.0.0.1' || $ip === gethostname()) {
        $connection = @fsockopen('8.8.8.8', 53, $errno, $errstr, 1);
        if ($connection) {
            $ip = stream_socket_get_name($connection, true);
            $ip = substr($ip, 0, strrpos($ip, ':'));
            fclose($connection);
        }
    }
    return $ip;
}
?> 