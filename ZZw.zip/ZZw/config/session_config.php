<?php
/**
 * Session Security Configuration
 * This file contains all session security settings for the application
 */

// Prevent direct access
if (!defined('SECURE_ACCESS')) {
    define('SECURE_ACCESS', true);
}

// Set secure session parameters BEFORE starting the session
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.cookie_httponly', 1);           // Prevent XSS access to session cookie
    ini_set('session.cookie_secure', 0);             // 0 for HTTP in LAN, 1 for HTTPS
    ini_set('session.cookie_samesite', 'Strict');    // Prevent CSRF attacks
    ini_set('session.use_strict_mode', 1);           // Use strict mode
    ini_set('session.use_only_cookies', 1);          // Only use cookies for session
    ini_set('session.cookie_lifetime', 0);           // Session cookie (deleted when browser closes)
    ini_set('session.gc_maxlifetime', 3600);        // 1 hour session timeout
    ini_set('session.gc_probability', 1);            // Garbage collection probability
    ini_set('session.gc_divisor', 100);              // Garbage collection divisor
    
    // Start session
    session_start();
} else if (session_status() === PHP_SESSION_ACTIVE) {
    // Session is already active, just continue
    // Note: We can't change session settings now, but the session is already secure
}

/**
 * Regenerate session ID to prevent session fixation (optimized)
 */
function regenerate_session_id() {
    if (session_status() === PHP_SESSION_ACTIVE) {
        // Regenerate session ID every 60 minutes instead of 30 (reduces overhead)
        if (!isset($_SESSION['last_regeneration']) || 
            (time() - $_SESSION['last_regeneration']) > 3600) {
            session_regenerate_id(true);
            $_SESSION['last_regeneration'] = time();
        }
    }
}

/**
 * Check if session has expired (optimized)
 */
function check_session_expiry() {
    $session_timeout = 3600; // 1 hour in seconds
    
    // Only check every 5 minutes to reduce overhead
    if (isset($_SESSION['last_activity_check']) && 
        (time() - $_SESSION['last_activity_check']) < 300) {
        return true;
    }
    
    if (isset($_SESSION['last_activity']) && 
        (time() - $_SESSION['last_activity']) > $session_timeout) {
        // Session expired
        session_unset();
        session_destroy();
        return false;
    }
    
    // Update timestamps less frequently
    $_SESSION['last_activity'] = time();
    $_SESSION['last_activity_check'] = time();
    return true;
}

/**
 * Validate session security (optimized)
 */
function validate_session_security() {
    // Check if user is logged in
    if (!isset($_SESSION['user_logged_in']) || $_SESSION['user_logged_in'] !== true) {
        return false;
    }
    
    // Check session expiry (optimized)
    if (!check_session_expiry()) {
        return false;
    }
    
    // Regenerate session ID if needed (optimized)
    regenerate_session_id();
    
    return true;
}

/**
 * Set session data securely
 */
function set_secure_session_data($user_data) {
    // Clear any existing session data
    session_unset();
    
    // Set session data
    $_SESSION['user_logged_in'] = true;
    $_SESSION['user_id'] = $user_data['id'];
    $_SESSION['user_username'] = $user_data['username'];
    $_SESSION['user_name'] = $user_data['name'];
    $_SESSION['user_role'] = $user_data['role'];
    $_SESSION['lang'] = !empty($user_data['language']) ? $user_data['language'] : 'en';
    
    // Set security timestamps
    $_SESSION['created_at'] = time();
    $_SESSION['last_activity'] = time();
    $_SESSION['last_regeneration'] = time();
    $_SESSION['last_activity_check'] = time();
    
    // Set user agent for additional security
    $_SESSION['user_agent'] = $_SERVER['HTTP_USER_AGENT'] ?? '';
}

/**
 * Verify user agent hasn't changed (optimized)
 */
function verify_user_agent() {
    // Only check every 10 minutes to reduce overhead
    if (isset($_SESSION['last_ua_check']) && 
        (time() - $_SESSION['last_ua_check']) < 600) {
        return true;
    }
    
    if (isset($_SESSION['user_agent']) && 
        isset($_SERVER['HTTP_USER_AGENT']) && 
        $_SESSION['user_agent'] !== $_SERVER['HTTP_USER_AGENT']) {
        // User agent changed, possible session hijacking
        session_unset();
        session_destroy();
        return false;
    }
    
    $_SESSION['last_ua_check'] = time();
    return true;
}

/**
 * Clean up session on logout
 */
function secure_logout() {
    // Clear all session data
    session_unset();
    
    // Destroy the session
    session_destroy();
    
    // Delete session cookie
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $params["path"], $params["domain"],
            $params["secure"], $params["httponly"]
        );
    }
}

// Initialize session security only if session is active
if (session_status() === PHP_SESSION_ACTIVE) {
    regenerate_session_id();
}
?>