<?php
require_once __DIR__ . '/translation.php';
$role = $_SESSION['user_role'] ?? '';
require_once __DIR__ . '/../config/database.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['lang'])) {
    if (!isset($_SESSION['lang']) || $_SESSION['lang'] !== $_POST['lang']) {
        $_SESSION['lang'] = $_POST['lang'];
        // Save language preference in DB if user is logged in
        if (isset($_SESSION['user_id'])) {
            $stmt = $pdo->prepare('UPDATE users SET language = ? WHERE id = ?');
            $stmt->execute([$_POST['lang'], $_SESSION['user_id']]);
        }
        header('Location: ' . $_SERVER['REQUEST_URI']);
        exit();
    }
}
if (!isset($_SESSION['lang'])) {
    $_SESSION['lang'] = 'en';
}
$currentPage = basename($_SERVER['PHP_SELF']);
$hideLangSwitcher = in_array($currentPage, ['add_reservation.php', 'edit_reservation.php']);
?>
<nav class="navbar">
  <div class="nav-container">
    <div class="nav-brand">
      <?php if (!$hideLangSwitcher): ?>
      <div class="nav-lang-switcher" style="position:relative;">
        <button type="button" id="langSwitcherBtn" class="lang-switcher-btn" aria-label="Switch language">
          <span style="font-size:1.3em;vertical-align:middle;">🌐</span>
          <span style="margin-left:6px;font-weight:600;letter-spacing:1px;">
            <?php echo strtoupper($_SESSION['lang']); ?>
          </span>
          <span style="margin-left:4px;font-size:0.9em;">▼</span>
        </button>
        <form method="post" action="" id="langSwitcherForm" class="lang-switcher-dropdown" style="display:none;position:absolute;top:110%;left:0;min-width:120px;background:#fff;border:1px solid #ccc;border-radius:8px;box-shadow:0 2px 8px rgba(0,0,0,0.08);z-index:1000;padding:0.5em 0;">
          <button type="submit" name="lang" value="en" class="lang-option" style="display:block;width:100%;background:none;border:none;padding:8px 18px;text-align:left;font-size:1em;cursor:pointer;<?php if ($_SESSION['lang']==='en') echo 'font-weight:bold;color:#b8860b;'; ?>">🇬🇧 English</button>
          <button type="submit" name="lang" value="fr" class="lang-option" style="display:block;width:100%;background:none;border:none;padding:8px 18px;text-align:left;font-size:1em;cursor:pointer;<?php if ($_SESSION['lang']==='fr') echo 'font-weight:bold;color:#b8860b;'; ?>">🇫🇷 Français</button>
        </form>
      </div>
      <?php endif; ?>
      <img src="assets/images/logo.png" alt="ABDELMOULA CAMP" class="nav-logo">
      <h1><?php echo t('ABDELMOULA CAMP', 'ABDELMOULA CAMP'); ?></h1>
    </div>
    <div class="nav-links">
      <a href="dashboard.php" class="<?php echo basename($_SERVER['PHP_SELF']) === 'dashboard.php' ? 'active' : ''; ?>"><?php echo t('dashboard', 'Dashboard'); ?></a>
      <a href="add_reservation.php" class="<?php echo basename($_SERVER['PHP_SELF']) === 'add_reservation.php' ? 'active' : ''; ?>"><?php echo t('add_reservation', 'Add Reservation'); ?></a>
      <a href="guests.php" class="<?php echo basename($_SERVER['PHP_SELF']) === 'guests.php' ? 'active' : ''; ?>"><?php echo t('guests', 'Guests'); ?></a>
      <a href="services.php" class="<?php echo basename($_SERVER['PHP_SELF']) === 'services.php' ? 'active' : ''; ?>"><?php echo t('services', 'Services'); ?></a>
      
        <a href="resources.php" class="<?php echo basename($_SERVER['PHP_SELF']) === 'resources.php' ? 'active' : ''; ?>"><?php echo t('resources', 'Resources'); ?></a>
     
      <?php if ($role === 'Director'): ?>
        <a href="users.php" class="<?php echo basename($_SERVER['PHP_SELF']) === 'users.php' ? 'active' : ''; ?>"><?php echo t('users', 'Users'); ?></a>
        <a href="TARIF.php" class="<?php echo basename($_SERVER['PHP_SELF']) === 'TARIF.php' ? 'active' : ''; ?>"><?php echo t('tarif', 'TARIF'); ?></a>
      <?php elseif ($role === 'Accountant'): ?>
        <a href="TARIF.php" class="<?php echo basename($_SERVER['PHP_SELF']) === 'TARIF.php' ? 'active' : ''; ?>"><?php echo t('tarif', 'TARIF'); ?></a>
      <?php endif; ?>
      <a href="logout.php"><?php echo t('logout', 'Logout'); ?></a>
    </div>
  </div>
</nav>
<script>
// Language switcher dropdown logic
const langBtn = document.getElementById('langSwitcherBtn');
const langForm = document.getElementById('langSwitcherForm');
if (langBtn && langForm) {
  langBtn.addEventListener('click', function(e) {
    e.stopPropagation();
    langForm.style.display = langForm.style.display === 'block' ? 'none' : 'block';
  });
  document.addEventListener('click', function(e) {
    if (!langForm.contains(e.target) && e.target !== langBtn) {
      langForm.style.display = 'none';
    }
  });
}
// Ensure full page reload after language change for AJAX-driven pages
if (document.querySelector('.lang-form')) {
  document.querySelector('.lang-form').addEventListener('submit', function() {
    setTimeout(function() { window.location.reload(true); }, 100);
  });
}
</script>
<style>
.lang-switcher-btn {
  background: #fffbe6;
  border: 1.5px solid #e0c97f;
  border-radius: 8px;
  padding: 6px 16px 6px 12px;
  font-size: 1.08em;
  color: #b8860b;
  font-weight: 600;
  cursor: pointer;
  box-shadow: 0 2px 8px rgba(184,134,11,0.08);
  transition: border-color 0.18s, box-shadow 0.18s;
  outline: none;
  display: flex;
  align-items: center;
  gap: 4px;
}
.lang-switcher-btn:hover, .lang-switcher-btn:focus {
  border-color: #b8860b;
  box-shadow: 0 4px 16px rgba(184,134,11,0.13);
}
.lang-switcher-dropdown {
  min-width: 120px;
  background: #fff;
  border: 1px solid #ccc;
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.08);
  z-index: 1000;
  padding: 0.5em 0;
}
.lang-option:hover, .lang-option:focus {
  background: #fffbe6;
  color: #b8860b;
}
</style>
