<?php
/**
 * Tariff Helper Functions
 * Handles tent pricing calculations based on reservation source and tent configuration
 */

/**
 * Map bed configuration to standard format
 * @param string $bed_configuration The bed configuration from the form/database
 * @return string Standardized bed configuration
 */
function mapBedConfiguration($bed_configuration) {
    $mapping = [
        'trilateral' => 'triple',
        'single' => 'single',
        'double' => 'double',
        'triple' => 'triple',
        'quadruple' => 'quadruple'
    ];
    
    return $mapping[$bed_configuration] ?? $bed_configuration;
}

/**
 * Get current active tariff version ID
 * @param PDO $pdo Database connection
 * @return int Active tariff version ID
 */
function getCurrentTariffVersion($pdo) {
    $stmt = $pdo->prepare("SELECT id FROM tariff_versions WHERE is_active = 1 ORDER BY activated_at DESC LIMIT 1");
    $stmt->execute();
    $result = $stmt->fetch();
    return $result ? intval($result['id']) : 1; // Default to version 1 if none active
}

/**
 * Get tent price from tariff table for specific version
 * @param PDO $pdo Database connection
 * @param string $tent_type ROYAL or NORMAL
 * @param string $bed_configuration single, double, triple, quadrilateral
 * @param string $reservation_source individual or agency
 * @param int $tariff_version_id Tariff version ID
 * @return float|null Price per night or null if not found
 */
function getTentPrice($pdo, $tent_type, $bed_configuration, $reservation_source, $tariff_version_id = null) {
    // Map the bed configuration to standard format
    $standard_bed_config = mapBedConfiguration($bed_configuration);
    
    // Use provided tariff version or current active version
    if ($tariff_version_id === null) {
        $tariff_version_id = getCurrentTariffVersion($pdo);
    }
    
    $stmt = $pdo->prepare("SELECT price_per_night FROM tariff_prices 
                          WHERE tent_type = ? AND bed_configuration = ? AND reservation_source = ? 
                          AND tariff_version_id = ? AND is_active = 1");
    $stmt->execute([$tent_type, $standard_bed_config, $reservation_source, $tariff_version_id]);
    $result = $stmt->fetch();
    
    $price = $result ? floatval($result['price_per_night']) : null;
    
    return $price;
}

/**
 * Calculate total accommodation price for a reservation
 * @param PDO $pdo Database connection
 * @param string $tent_specifications Tent specifications string
 * @param string $reservation_source individual or agency
 * @param int $nights Number of nights
 * @param int $tariff_version_id Tariff version ID
 * @return float Total accommodation price
 */
function calculateAccommodationPrice($pdo, $tent_specifications, $reservation_source, $nights, $tariff_version_id = null) {
    if (empty($tent_specifications)) {
        return 0;
    }
    
    $total_price = 0;
    $specs = explode(', ', $tent_specifications);
    
    foreach ($specs as $index => $spec) {
        $spec = trim($spec); // Remove any whitespace
        
        // Parse tent specification: "Tent 1: ROYAL - double"
        if (preg_match('/Tent\s*(\d+):\s*(\w+)\s*-\s*(\w+)/', $spec, $matches)) {
            $tent_number = $matches[1];
            $tent_type = $matches[2];
            $bed_config = $matches[3];
            
            $price_per_night = getTentPrice($pdo, $tent_type, $bed_config, $reservation_source, $tariff_version_id);
            if ($price_per_night !== null) {
                $tent_total = $price_per_night * $nights;
                $total_price += $tent_total;
            }
        }
    }
    
    return $total_price;
}

/**
 * Calculate accommodation price with exceptions using reservation_tents table directly
 * @param PDO $pdo Database connection
 * @param int $reservation_id Reservation ID
 * @param string $reservation_source Reservation source
 * @param int $nights Number of nights
 * @param array $exceptions Exceptions array
 * @param int $tariff_version_id Tariff version ID
 * @return float Total price
 */
function calculateAccommodationPriceWithExceptions($pdo, $reservation_id, $reservation_source, $nights, $exceptions = [], $tariff_version_id = null) {
    if (!$reservation_id) {
        return 0;
    }
    
    $total_price = 0;
    
    // Get assigned tents from reservation_tents table with bed configuration from tent_specifications
    $tents_query = "SELECT t.id, t.tent_number, t.tent_type, rt.start_date, rt.end_date 
                   FROM tents t 
                   JOIN reservation_tents rt ON t.id = rt.tent_id 
                   WHERE rt.reservation_id = ? 
                   ORDER BY t.tent_number";
    $tents_stmt = $pdo->prepare($tents_query);
    $tents_stmt->execute([$reservation_id]);
    $assigned_tents = $tents_stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get bed configurations from tent_specifications
    $reservation_stmt = $pdo->prepare("SELECT tent_specifications, boarding_information FROM reservations WHERE id = ?");
    $reservation_stmt->execute([$reservation_id]);
    $reservation = $reservation_stmt->fetch(PDO::FETCH_ASSOC);
    
    $bed_configs = [];
    if (!empty($reservation['tent_specifications'])) {
        $specs = explode(', ', $reservation['tent_specifications']);
        foreach ($specs as $spec) {
            if (preg_match('/Tent\s*(\d+):\s*(\w+)\s*-\s*(\w+)\s*\(Tent\s*#(\d+)\)/', $spec, $matches)) {
                $tent_number = $matches[1];
                $tent_type = $matches[2];
                $bed_config = $matches[3];
                $tent_display_number = $matches[4];
                
                // Find the tent ID that corresponds to this tent number AND type to avoid duplication
                $tent_stmt = $pdo->prepare("SELECT id FROM tents WHERE tent_number = ? AND UPPER(tent_type) = ? ORDER BY id LIMIT 1");
                $tent_stmt->execute([$tent_display_number, strtoupper($tent_type)]);
                $tent_result = $tent_stmt->fetch();
                if ($tent_result) {
                    $bed_configs[$tent_result['id']] = $bed_config;
                }
            }
        }
    }
    
    // Get boarding information from the dedicated column
    $boarding_configs = [];
    if (!empty($reservation['boarding_information'])) {
        $boarding_data = json_decode($reservation['boarding_information'], true);
        if (isset($boarding_data['tents']) && is_array($boarding_data['tents'])) {
            foreach ($boarding_data['tents'] as $boarding) {
                $tent_number = $boarding['tent_number'];
                if (isset($boarding['half_board_days']) && $boarding['half_board_days'] > 0) {
                    $boarding_configs[$tent_number]['half_board'] = intval($boarding['half_board_days']);
                }
                if (isset($boarding['full_board_days']) && $boarding['full_board_days'] > 0) {
                    $boarding_configs[$tent_number]['full_board'] = intval($boarding['full_board_days']);
                }
            }
        }
    }
    
    // Group exceptions by tent ID
    $exceptions_by_tent = [];
    foreach ($exceptions as $exception) {
        if (!empty($exception['assigned_tent_id'])) {
            $tent_id = $exception['assigned_tent_id'];
            if (!isset($exceptions_by_tent[$tent_id])) {
                $exceptions_by_tent[$tent_id] = [];
            }
            $exceptions_by_tent[$tent_id][] = $exception;
        }
    }
    
    foreach ($assigned_tents as $index => $tent) {
        $tent_id = $tent['id'];
        $tent_type = $tent['tent_type'];
        $tent_spec_number = $index + 1; // Corresponds to "Tent 1", "Tent 2" in specifications
        
        // Get bed configuration for this tent
        $bed_config = $bed_configs[$tent_id] ?? 'double'; // Default to double if not found
        
        // Get the tent number from specifications for boarding lookup (same as display function)
        $tent_spec_number_display = null;
        if (!empty($reservation['tent_specifications'])) {
            $specs = explode(', ', $reservation['tent_specifications']);
            foreach ($specs as $spec) {
                if (preg_match('/Tent\s*(\d+):\s*(\w+)\s*-\s*(\w+)\s*\(Tent\s*#(\d+)\)/', $spec, $matches)) {
                    $tent_number = $matches[1];
                    $tent_type_spec = $matches[2];
                    $bed_config_spec = $matches[3];
                    $tent_display_number = $matches[4];
                    
                    // Find the tent ID that corresponds to this tent number AND type to avoid duplication
                    $tent_stmt = $pdo->prepare("SELECT id FROM tents WHERE tent_number = ? AND UPPER(tent_type) = ? ORDER BY id LIMIT 1");
                    $tent_stmt->execute([$tent_display_number, strtoupper($tent_type_spec)]);
                    $tent_result = $tent_stmt->fetch();
                    if ($tent_result && $tent_result['id'] == $tent_id) {
                        $tent_spec_number_display = $tent_number;
                        break;
                    }
                }
            }
        }
        
        // Check if this tent has exceptions
        $tent_exceptions = $exceptions_by_tent[$tent_id] ?? [];
        $exception_count = count($tent_exceptions);
        
        // Check if this tent has kids
        $kids_number = getKidsNumberForTent($pdo, $reservation['tent_specifications'], $tent_id);
        
        if ($exception_count > 0) {
            // Calculate price with exceptions (same logic as display)
            $bed_numbers = getBedNumbers($bed_config);
            $effective_beds = max(1, $bed_numbers - $exception_count); // Reduce beds by exception count, minimum 1
            
            // Check if all beds are taken by exceptions (tent is free)
            if ($exception_count >= $bed_numbers) {
                // All beds are exceptions, tent is free
                $tent_total = 0; // Tent is free
            } else if ($effective_beds == 1) {
                // Only 1 bed remaining, check if original tent was single
                if ($bed_numbers == 1) {
                    // Original tent was single, so it's free
                    $tent_total = 0; // Single tent is free
                } else {
                    // Original tent was larger (double/triple/quadruple), charge for single tent
                    if ($kids_number > 0) {
                        // Calculate kids pricing for single bed configuration
                        require_once 'kids_pricing_helper.php';
                        $kids_pricing = calculateKidsPricing($pdo, $tent_type, 'single', $reservation_source, $kids_number, $nights);
                        
                        // Calculate total occupied beds (exceptions + kids)
                        $total_occupied = $exception_count + $kids_number;
                        
                        if ($total_occupied >= $bed_numbers) {
                            // All beds are occupied by exceptions and kids
                            $tent_total = $kids_pricing['total_price'];
                        } else {
                            $tent_total = $kids_pricing['total_price'];
                        }
                    } else {
                    $price_per_night = getTentPrice($pdo, $tent_type, 'single', $reservation_source, $tariff_version_id);
                    $tent_total = $price_per_night !== null ? ($price_per_night * $nights) : 0;
                    }
                }
            } else {
                // Get price for effective bed configuration
                $effective_bed_config = getBedConfigFromNumbers($effective_beds);
                if ($kids_number > 0) {
                    // Calculate kids pricing for effective bed configuration
                    require_once 'kids_pricing_helper.php';
                    $kids_pricing = calculateKidsPricing($pdo, $tent_type, $effective_bed_config, $reservation_source, $kids_number, $nights);
                    
                    // Calculate total occupied beds (exceptions + kids)
                    $total_occupied = $exception_count + $kids_number;
                    
                    if ($total_occupied >= $bed_numbers) {
                        // All beds are occupied by exceptions and kids
                        $tent_total = $kids_pricing['total_price'];
                    } else {
                        $tent_total = $kids_pricing['total_price'];
                    }
                } else {
                $price_per_night = getTentPrice($pdo, $tent_type, $effective_bed_config, $reservation_source, $tariff_version_id);
                $tent_total = $price_per_night !== null ? ($price_per_night * $nights) : 0;
                }
            }
            
            // Add exception prices if not free
            foreach ($tent_exceptions as $exception) {
                if (!isset($exception['is_free']) || !$exception['is_free']) {
                    $exception_price = floatval($exception['price_per_night'] ?? 0);
                    $tent_total += $exception_price * $nights;
                }
            }
            
            $total_price += $tent_total;
        } else {
            // No exceptions, calculate normal price
            if ($kids_number > 0) {
                // Calculate kids pricing
                require_once 'kids_pricing_helper.php';
                $kids_pricing = calculateKidsPricing($pdo, $tent_type, $bed_config, $reservation_source, $kids_number, $nights);
                $tent_total = $kids_pricing['total_price'];
                $total_price += $tent_total;
            } else {
            $price_per_night = getTentPrice($pdo, $tent_type, $bed_config, $reservation_source, $tariff_version_id);
            if ($price_per_night !== null) {
                $tent_total = $price_per_night * $nights;
                $total_price += $tent_total;
                }
            }
        }
        
        // Add boarding costs
        $boarding_config = $boarding_configs[$tent_spec_number_display] ?? [];
        
        if (isset($boarding_config['half_board']) && $boarding_config['half_board'] > 0) {
            // Use original bed configuration from boarding data for boarding price calculation
            $original_bed_config = $bed_config;
            if (!empty($reservation['boarding_information'])) {
                $boarding_data = json_decode($reservation['boarding_information'], true);
                if (isset($boarding_data['tents'])) {
                    foreach ($boarding_data['tents'] as $boarding) {
                        if ($boarding['tent_number'] == $tent_spec_number_display) {
                            $original_bed_config = $boarding['bed_config'];
                            break;
                        }
                    }
                }
            }
            $half_board_price = getBoardingPrice($pdo, $reservation_source, $tent_type, $original_bed_config, 'half_board', $tariff_version_id);
            // Per-person split using original capacity; exclude exceptions; apply kids discount to kids share
            require_once 'kids_pricing_helper.php';
            $bed_capacity = getBedCapacity($original_bed_config);
            $effective_capacity = max(0, $bed_capacity - $exception_count);
            $per_person_boarding = $bed_capacity > 0 ? ($half_board_price / $bed_capacity) : 0;
            $kids_discount_percentage = getKidsDiscountPercentage($pdo);
            $kids_count_boarding = min($kids_number, $effective_capacity);
            $adult_count_boarding = max(0, $effective_capacity - $kids_count_boarding);
            $per_day_boarding_total = ($adult_count_boarding * $per_person_boarding) + ($kids_count_boarding * $per_person_boarding * (1 - ($kids_discount_percentage / 100)));
            $total_price += $per_day_boarding_total * $boarding_config['half_board'];
        }
        
        if (isset($boarding_config['full_board']) && $boarding_config['full_board'] > 0) {
            // Use original bed configuration from boarding data for boarding price calculation
            $original_bed_config = $bed_config;
            if (!empty($reservation['boarding_information'])) {
                $boarding_data = json_decode($reservation['boarding_information'], true);
                if (isset($boarding_data['tents'])) {
                    foreach ($boarding_data['tents'] as $boarding) {
                        if ($boarding['tent_number'] == $tent_spec_number_display) {
                            $original_bed_config = $boarding['bed_config'];
                            break;
                        }
                    }
                }
            }
            $full_board_price = getBoardingPrice($pdo, $reservation_source, $tent_type, $original_bed_config, 'full_board', $tariff_version_id);
            // Per-person split using original capacity; exclude exceptions; apply kids discount to kids share
            require_once 'kids_pricing_helper.php';
            $bed_capacity = getBedCapacity($original_bed_config);
            $effective_capacity = max(0, $bed_capacity - $exception_count);
            $per_person_boarding = $bed_capacity > 0 ? ($full_board_price / $bed_capacity) : 0;
            $kids_discount_percentage = getKidsDiscountPercentage($pdo);
            $kids_count_boarding = min($kids_number, $effective_capacity);
            $adult_count_boarding = max(0, $effective_capacity - $kids_count_boarding);
            $per_day_boarding_total = ($adult_count_boarding * $per_person_boarding) + ($kids_count_boarding * $per_person_boarding * (1 - ($kids_discount_percentage / 100)));
            $total_price += $per_day_boarding_total * $boarding_config['full_board'];
        }
    }
    
    return $total_price;
}

/**
 * Calculate accommodation price with exceptions using tent_specifications (legacy function for backward compatibility)
 * @param PDO $pdo Database connection
 * @param string $tent_specifications Tent specifications string
 * @param string $reservation_source Reservation source
 * @param int $nights Number of nights
 * @param array $exceptions Exceptions array
 * @param int $tariff_version_id Tariff version ID
 * @return float Total price
 */
function calculateAccommodationPriceWithExceptionsLegacy($pdo, $tent_specifications, $reservation_source, $nights, $exceptions = [], $tariff_version_id = null) {
    if (empty($tent_specifications)) {
        return 0;
    }
    
    $total_price = 0;
    $specs = explode(', ', $tent_specifications);
    
    // Group exceptions by tent ID
    $exceptions_by_tent = [];
    foreach ($exceptions as $exception) {
        if (!empty($exception['assigned_tent_id'])) {
            $tent_id = $exception['assigned_tent_id'];
            if (!isset($exceptions_by_tent[$tent_id])) {
                $exceptions_by_tent[$tent_id] = [];
            }
            $exceptions_by_tent[$tent_id][] = $exception;
        }
    }
    
    // Create a mapping of tent numbers to tent IDs and bed configurations
    $tent_mapping = [];
    foreach ($specs as $index => $spec) {
        $spec = trim($spec);
        
        // Parse tent specification: "Tent 1: ROYAL - double (Tent #25)"
        if (preg_match('/Tent\s*(\d+):\s*(\w+)\s*-\s*(\w+)\s*\(Tent\s*#(\d+)\)/', $spec, $matches)) {
            $tent_number = $matches[1];
            $tent_type = $matches[2];
            $bed_config = $matches[3];
            $tent_display_number = $matches[4]; // This is the tent number for display
            
            // Find the tent ID that corresponds to this tent number
            $tent_id = null;
            $tent_stmt = $pdo->prepare("SELECT id FROM tents WHERE tent_number = ? ORDER BY id LIMIT 1");
            $tent_stmt->execute([$tent_display_number]);
            $tent_result = $tent_stmt->fetch();
            if ($tent_result) {
                $tent_id = $tent_result['id'];
                $tent_mapping[$tent_id] = [
                    'tent_type' => $tent_type,
                    'bed_config' => $bed_config,
                    'tent_number' => $tent_display_number
                ];
            }
        }
    }
    
    // Now process each tent with its exceptions
    foreach ($tent_mapping as $tent_id => $tent_info) {
        $tent_type = $tent_info['tent_type'];
        $bed_config = $tent_info['bed_config'];
        
        // Check if this tent has exceptions
        $tent_exceptions = $exceptions_by_tent[$tent_id] ?? [];
        $exception_count = count($tent_exceptions);
        
        if ($exception_count > 0) {
            // Calculate price with exceptions and kids
            $bed_numbers = getBedNumbers($bed_config);
            $tent_total = calculateTentPriceWithExceptionsAndKids($pdo, $tent_type, $bed_config, $bed_numbers, $exception_count, $tent_exceptions, $reservation_source, $nights, $tent_specifications, $tent_id, $tariff_version_id);
            $total_price += $tent_total;
        } else {
            // No exceptions, calculate normal price
            $price_per_night = getTentPrice($pdo, $tent_type, $bed_config, $reservation_source, $tariff_version_id);
            if ($price_per_night !== null) {
                $tent_total = $price_per_night * $nights;
                
                // Check if this tent has kids
                $kids_number = getKidsNumberForTent($pdo, $tent_specifications, $tent_id);
                if ($kids_number > 0) {
                    // Calculate kids pricing
                    require_once 'kids_pricing_helper.php';
                    $kids_pricing = calculateKidsPricing($pdo, $tent_type, $bed_config, $reservation_source, $kids_number, $nights);
                    $tent_total = $kids_pricing['total_price'];
                }
                
                $total_price += $tent_total;
            }
        }
    }
    
    return $total_price;
}

/**
 * Calculate tent price with exceptions and kids
 * @param PDO $pdo Database connection
 * @param string $tent_type Tent type
 * @param string $bed_config Bed configuration
 * @param int $bed_numbers Number of beds
 * @param int $exception_count Number of exceptions
 * @param array $tent_exceptions Array of exceptions
 * @param string $reservation_source Reservation source
 * @param int $nights Number of nights
 * @param string $tent_specifications Tent specifications string
 * @param int $tent_id Tent ID
 * @param int $tariff_version_id Tariff version ID
 * @return float Total tent price
 */
function calculateTentPriceWithExceptionsAndKids($pdo, $tent_type, $bed_config, $bed_numbers, $exception_count, $tent_exceptions, $reservation_source, $nights, $tent_specifications, $tent_id, $tariff_version_id) {
    $tent_total = 0;
    
    // Check if this tent has kids
    $kids_number = getKidsNumberForTent($pdo, $tent_specifications, $tent_id);
    
    // Calculate total occupied beds (exceptions + kids)
    $total_occupied = $exception_count + $kids_number;
    
    if ($total_occupied >= $bed_numbers) {
        // All beds are occupied by exceptions and kids, no regular tent price
        $tent_total = 0;
    } else {
        // Calculate effective bed configuration after exceptions
        $effective_beds = max(1, $bed_numbers - $exception_count);
        $effective_bed_config = getBedConfigFromNumbers($effective_beds);
        
        if ($effective_beds == 1) {
            // Only 1 bed remaining, check if original tent was single
            if ($bed_numbers == 1) {
                // Original tent was single, so it's free
                $tent_total = 0;
            } else {
                // Original tent was larger, charge for single tent
                $price_per_night = getTentPrice($pdo, $tent_type, 'single', $reservation_source, $tariff_version_id);
                $tent_total = $price_per_night !== null ? ($price_per_night * $nights) : 0;
            }
        } else {
            // Get price for effective bed configuration
            $price_per_night = getTentPrice($pdo, $tent_type, $effective_bed_config, $reservation_source, $tariff_version_id);
            $tent_total = $price_per_night !== null ? ($price_per_night * $nights) : 0;
        }
        
        // Apply kids pricing if there are kids
        if ($kids_number > 0) {
            require_once 'kids_pricing_helper.php';
            $kids_pricing = calculateKidsPricing($pdo, $tent_type, $effective_bed_config, $reservation_source, $kids_number, $nights);
            $tent_total = $kids_pricing['total_price'];
        }
    }
    
    // Add exception prices if not free
    foreach ($tent_exceptions as $exception) {
        if (!isset($exception['is_free']) || !$exception['is_free']) {
            $exception_price = floatval($exception['price_per_night'] ?? 0);
            $tent_total += $exception_price * $nights;
        }
    }
    
    return $tent_total;
}

/**
 * Get kids number for a specific tent from tent specifications
 * @param PDO $pdo Database connection
 * @param string $tent_specifications Tent specifications string
 * @param int $tent_id Tent ID
 * @return int Number of kids
 */
function getKidsNumberForTent($pdo, $tent_specifications, $tent_id) {
    $specs = explode(', ', $tent_specifications);
    
    foreach ($specs as $spec) {
        $spec = trim($spec);
        
        // Parse tent specification: "Tent 1: ROYAL - double (Tent #25) [Kids: 2]"
        if (preg_match('/Tent\s*(\d+):\s*(\w+)\s*-\s*(\w+)\s*\(Tent\s*#(\d+)\)(.*)/', $spec, $matches)) {
            $tent_type_spec = $matches[2];
            $tent_display_number = $matches[4];
            $additional_info = $matches[5] ?? '';
            
            // Check if this tent matches the tent_id by both tent_number and tent_type
            $tent_stmt = $pdo->prepare("SELECT tent_number, tent_type FROM tents WHERE id = ?");
            $tent_stmt->execute([$tent_id]);
            $tent_result = $tent_stmt->fetch();
            
            if ($tent_result && $tent_result['tent_number'] == $tent_display_number && strtoupper($tent_result['tent_type']) == strtoupper($tent_type_spec)) {
                // Parse kids information
                if (preg_match('/\[Kids:\s*(\d+)\]/', $additional_info, $kids_matches)) {
                    return intval($kids_matches[1]);
                }
            }
        }
    }
    
    return 0;
}

/**
 * Get number of beds for a bed configuration
 * @param string $bed_config Bed configuration (single, double, triple, quadruple)
 * @return int Number of beds
 */
function getBedNumbers($bed_config) {
    $bed_numbers = [
        'single' => 1,
        'double' => 2,
        'triple' => 3,
        'quadruple' => 4
    ];
    
    return $bed_numbers[$bed_config] ?? 1;
}

/**
 * Get bed capacity for a bed configuration (alias for getBedNumbers)
 * @param string $bed_configuration Bed configuration
 * @return int Number of beds
 */
function getBedCapacity($bed_configuration) {
    return getBedNumbers($bed_configuration);
}

/**
 * Get bed configuration from number of beds
 * @param int $bed_numbers Number of beds
 * @return string Bed configuration
 */
function getBedConfigFromNumbers($bed_numbers) {
    $bed_configs = [
        1 => 'single',
        2 => 'double',
        3 => 'triple',
        4 => 'quadruple'
    ];
    
    return $bed_configs[$bed_numbers] ?? 'single';
}

/**
 * Calculate total reservation price with new tariff system
 * @param PDO $pdo Database connection
 * @param array $reservation Reservation data
 * @param array $guest Guest data
 * @return float Total price
 */
function calculateTotalReservationPrice($pdo, $reservation, $guest) {
    $total_price = 0;
    $tariff_version_id = $reservation['tariff_version_id'] ?? null;
    
    // Get exceptions for this reservation
    $exceptions = [];
    if (isset($reservation['id'])) {
        $exceptions_stmt = $pdo->prepare("SELECT * FROM reservation_exceptions WHERE reservation_id = ?");
        $exceptions_stmt->execute([$reservation['id']]);
        $exceptions = $exceptions_stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    // Calculate accommodation price using new tariff system with exceptions
    $accommodation_price = calculateAccommodationPriceWithExceptions(
        $pdo, 
        $reservation['id'], 
        $reservation['reservation_source'], 
        $reservation['nights'],
        $exceptions,
        $tariff_version_id
    );
    $total_price += $accommodation_price;
    
    // Add 4x4 car costs - calculate each car individually for correct pricing
    if (isset($reservation['id'])) {
        $cars_total = calculateCarPricingCorrectly($pdo, $reservation['id'], $tariff_version_id);
    } else {
        // Fallback for new reservations without ID yet
        $car_days = isset($reservation['car_days_total']) ? $reservation['car_days_total'] : $reservation['car_days'];
        $car_price_per_day = getCar4x4Price($pdo, $car_days, $tariff_version_id);
        $cars_total = $car_price_per_day * $car_days;
    }
    $total_price += $cars_total;
    
    // Add staff costs
    $driver_price = getDriverPrice($pdo, $tariff_version_id);
    $guide_price = getGuidePrice($pdo, $tariff_version_id);
    $driver_days = isset($reservation['driver_days_total']) ? $reservation['driver_days_total'] : $reservation['driver_days'];
    $guide_days = isset($reservation['guide_days_total']) ? $reservation['guide_days_total'] : $reservation['guide_days'];
    $staff_total = ($driver_price * $driver_days) + ($guide_price * $guide_days);
    $total_price += $staff_total;
    
    // Add services costs
    $services_total = 0;
    if (!empty($reservation['services_data'])) {
        $services_data = json_decode($reservation['services_data'], true);
        if (is_array($services_data)) {
            foreach ($services_data as $service_id => $service) {
                if (isset($service['selected']) && $service['selected'] == '1') {
                    $service_price = floatval($service['price'] ?? 0);
                    $services_total += $service_price;
                }
            }
        }
    }
    
    // Add tourist tax from database column
    $tourist_tax_total = floatval($reservation['tourist_tax'] ?? 0);
    
    $total_price += $services_total + $tourist_tax_total;
    
    // Apply discount
    $discount = 0;
    if (!empty($reservation['discount_type']) && $reservation['discount_type'] !== 'none' && floatval($reservation['discount_value']) > 0) {
        if ($reservation['discount_type'] === 'percent') {
            $discount = ($total_price * floatval($reservation['discount_value'])) / 100.0;
        } elseif ($reservation['discount_type'] === 'amount') {
            $discount = floatval($reservation['discount_value']);
        }
        $total_price -= $discount;
        if ($total_price < 0) $total_price = 0;
    }
    return $total_price;
}

/**
 * Get price breakdown for display
 * @param PDO $pdo Database connection
 * @param array $reservation Reservation data
 * @param array $guest Guest data
 * @return array Price breakdown
 */
function getPriceBreakdown($pdo, $reservation, $guest, $translations = []) {
    $breakdown = [];
    $tariff_version_id = $reservation['tariff_version_id'] ?? null;
    
    // Get exceptions for this reservation
    $exceptions = [];
    if (isset($reservation['id'])) {
        $exceptions_stmt = $pdo->prepare("SELECT * FROM reservation_exceptions WHERE reservation_id = ?");
        $exceptions_stmt->execute([$reservation['id']]);
        $exceptions = $exceptions_stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    // Accommodation breakdown with exceptions
    $accommodation_price = calculateAccommodationPriceWithExceptions(
        $pdo, 
        $reservation['id'], 
        $reservation['reservation_source'], 
        $reservation['nights'],
        $exceptions,
        $tariff_version_id
    );
    $breakdown['accommodation'] = [
        'label' => ($translations['accommodation'] ?? 'Accommodation') . ' (' . $reservation['reservation_source'] . ')',
        'price' => $accommodation_price,
        'details' => getAccommodationDetails($pdo, $reservation, $tariff_version_id, $translations)
    ];
    
    // Car costs - calculate each car individually for correct pricing
    if (isset($reservation['id'])) {
        $cars_total = calculateCarPricingCorrectly($pdo, $reservation['id'], $tariff_version_id);
        // Get total car days for display purposes
        $car_days = isset($reservation['car_days_total']) ? $reservation['car_days_total'] : $reservation['car_days'];
        
        // Get detailed breakdown for each car
        $stmt = $pdo->prepare("SELECT start_date, end_date FROM reservation_cars WHERE reservation_id = ? ORDER BY start_date");
        $stmt->execute([$reservation['id']]);
        $assigned_cars = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Group cars by night count for better readability
        $one_night_cars = [];
        $multi_night_cars = [];
        $one_night_total = 0;
        $multi_night_total = 0;
        
        foreach ($assigned_cars as $car) {
            $start_date = new DateTime($car['start_date']);
            $end_date = new DateTime($car['end_date']);
            $car_nights = $end_date->diff($start_date)->days;
            $car_price_per_night = getCar4x4Price($pdo, $car_nights, $tariff_version_id);
            $car_total = $car_price_per_night * $car_nights;
            
            if ($car_nights == 1) {
                $one_night_cars[] = $car_total;
                $one_night_total += $car_total;
            } else {
                $multi_night_cars[] = ['nights' => $car_nights, 'total' => $car_total];
                $multi_night_total += $car_total;
            }
        }
        
        // Build readable summary
        $car_summary_parts = [];
        
        if (count($one_night_cars) > 0) {
            $car_summary_parts[] = count($one_night_cars) . " " . (count($one_night_cars) === 1 ? ($translations['car'] ?? 'car') : ($translations['cars'] ?? 'cars')) . " × 1 " . ($translations['night'] ?? 'night') . " (2" . ($translations['day'] ?? 'd') . ") = " . number_format($one_night_total, 2) . " TND";
        }
        
        if (count($multi_night_cars) > 0) {
            // Group multi-night cars by night count
            $night_groups = [];
            foreach ($multi_night_cars as $car) {
                $nights = $car['nights'];
                if (!isset($night_groups[$nights])) {
                    $night_groups[$nights] = ['count' => 0, 'total' => 0];
                }
                $night_groups[$nights]['count']++;
                $night_groups[$nights]['total'] += $car['total'];
            }
            
            foreach ($night_groups as $nights => $group) {
                $days = $nights + 1; // Days = nights + 1 (includes travel day)
                $car_summary_parts[] = $group['count'] . " " . ($group['count'] === 1 ? ($translations['car'] ?? 'car') : ($translations['cars'] ?? 'cars')) . " × " . $nights . " " . ($nights === 1 ? ($translations['night'] ?? 'night') : ($translations['nights'] ?? 'nights')) . "(" . $days . ($translations['day'] ?? 'd') . ") = " . number_format($group['total'], 2) . " TND";
            }
        }
        
        $cars_details = implode("; ", $car_summary_parts);
    } else {
        // Fallback for new reservations without ID yet
        $car_days = isset($reservation['car_days_total']) ? $reservation['car_days_total'] : $reservation['car_days'];
        $car_price_per_day = getCar4x4Price($pdo, $car_days, $tariff_version_id);
        $cars_total = $car_price_per_day * $car_days;
        $cars_details = $car_days . " " . ($translations['car_days'] ?? 'car-days') . " × " . number_format($car_price_per_day, 2) . " TND";
    }
    $breakdown['cars'] = [
        'label' => $translations['cars_4x4'] ?? '4x4 Cars',
        'price' => $cars_total,
        'details' => $cars_details
    ];
    
    // Staff costs
    $driver_price = getDriverPrice($pdo, $tariff_version_id);
    $guide_price = getGuidePrice($pdo, $tariff_version_id);
    $driver_days = isset($reservation['driver_days_total']) ? $reservation['driver_days_total'] : $reservation['driver_days'];
    $guide_days = isset($reservation['guide_days_total']) ? $reservation['guide_days_total'] : $reservation['guide_days'];
    $staff_total = ($driver_price * $driver_days) + ($guide_price * $guide_days);
    $staff_details = [];
    if ($driver_days > 0) {
        $driver_nights = $driver_days - 1; // Nights = days - 1 (since days includes travel day)
        $staff_details[] = $driver_days . ' ' . ($translations['driver_days'] ?? 'driver-days') . '(' . $driver_nights . ($translations['night_abbr'] ?? 'N') . ') × ' . $driver_price . ' TND';
    }
    if ($guide_days > 0) {
        $guide_nights = $guide_days - 1; // Nights = days - 1 (since days includes travel day)
        $staff_details[] = $guide_days . ' ' . ($translations['guide_days'] ?? 'guide-days') . '(' . $guide_nights . ($translations['night_abbr'] ?? 'N') . ') × ' . $guide_price . ' TND';
    }
    $breakdown['staff'] = [
        'label' => $translations['staff'] ?? 'Staff',
        'price' => $staff_total,
        'details' => implode(' + ', $staff_details)
    ];
    
    // Services
    $services_total = 0;
    $services_details = [];
    if (!empty($reservation['services_data'])) {
        $services_data = json_decode($reservation['services_data'], true);
        if (is_array($services_data)) {
            // Get service names from database
            $service_names = [];
            if (!empty($services_data)) {
                $service_ids = array_filter(array_keys($services_data), 'is_numeric');
                if (!empty($service_ids)) {
                    $placeholders = str_repeat('?,', count($service_ids) - 1) . '?';
                    $service_stmt = $pdo->prepare("SELECT id, name FROM services WHERE id IN ($placeholders)");
                    $service_stmt->execute($service_ids);
                    $service_names = $service_stmt->fetchAll(PDO::FETCH_KEY_PAIR);
                }
            }
            foreach ($services_data as $service_id => $service) {
                if (isset($service['selected']) && $service['selected'] == '1') {
                    $service_price = floatval($service['price'] ?? 0);
                    $services_total += $service_price;
                    $service_name = $service_names[$service_id] ?? "Service #$service_id";
                    $services_details[] = $service_name . ': ' . $service_price . ' TND';
                }
            }
        }
    }
    $breakdown['services'] = [
        'label' => $translations['services'] ?? 'Services',
        'price' => $services_total,
        'details' => implode(', ', $services_details)
    ];
    
    // Tourist Tax as its own category from database column
    $tourist_tax_total = floatval($reservation['tourist_tax'] ?? 0);
    if ($tourist_tax_total > 0) {
        $breakdown['tourist_tax'] = [
            'label' => $translations['tourist_tax'] ?? 'Tourist Tax',
            'price' => $tourist_tax_total,
            'details' => ''
        ];
    }

    // Discount
    $discount = 0;
    $discount_label = '';
    if (!empty($reservation['discount_type']) && $reservation['discount_type'] !== 'none' && floatval($reservation['discount_value']) > 0) {
        if ($reservation['discount_type'] === 'percent') {
            $discount = ($accommodation_price + $cars_total + $staff_total + $services_total) * floatval($reservation['discount_value']) / 100.0;
            $discount_label = ($translations['discount'] ?? 'Discount') . ' (' . floatval($reservation['discount_value']) . '%)';
        } elseif ($reservation['discount_type'] === 'amount') {
            $discount = floatval($reservation['discount_value']);
            $discount_label = ($translations['discount'] ?? 'Discount') . ' (' . ($translations['fixed_amount'] ?? 'Fixed Amount') . ')';
        }
        $breakdown['discount'] = [
            'label' => $discount_label,
            'price' => -$discount,
            'details' => $discount_label
        ];
    }
    return $breakdown;
}

/**
 * Get accommodation details for display using reservation_tents table directly
 * @param PDO $pdo Database connection
 * @param array $reservation Reservation data
 * @param int $tariff_version_id Tariff version ID
 * @return array Accommodation details
 */
function getAccommodationDetails($pdo, $reservation, $tariff_version_id = null, $translations = []) {
    if (!isset($reservation['id'])) {
        return [];
    }
    
    $details = [];
    
    // Get assigned tents from reservation_tents table
    $tents_query = "SELECT t.id, t.tent_number, t.tent_type, rt.start_date, rt.end_date 
                   FROM tents t 
                   JOIN reservation_tents rt ON t.id = rt.tent_id 
                   WHERE rt.reservation_id = ? 
                   ORDER BY t.tent_number";
    $tents_stmt = $pdo->prepare($tents_query);
    $tents_stmt->execute([$reservation['id']]);
    $assigned_tents = $tents_stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get bed configurations from tent_specifications
    $bed_configs = [];
    if (!empty($reservation['tent_specifications'])) {
        $specs = explode(', ', $reservation['tent_specifications']);
        foreach ($specs as $spec) {
            if (preg_match('/Tent\s*(\d+):\s*(\w+)\s*-\s*(\w+)\s*\(Tent\s*#(\d+)\)/', $spec, $matches)) {
                $tent_number = $matches[1];
                $tent_type = $matches[2];
                $bed_config = $matches[3];
                $tent_display_number = $matches[4];
                
                // Find the tent ID that corresponds to this tent number AND type to avoid duplication
                $tent_stmt = $pdo->prepare("SELECT id FROM tents WHERE tent_number = ? AND UPPER(tent_type) = ? ORDER BY id LIMIT 1");
                $tent_stmt->execute([$tent_display_number, strtoupper($tent_type)]);
                $tent_result = $tent_stmt->fetch();
                if ($tent_result) {
                    $bed_configs[$tent_result['id']] = [
                        'bed_config' => $bed_config,
                        'tent_number' => $tent_number
                    ];
                }
            }
        }
    }
    
    // Get boarding information from the dedicated column
    $boarding_configs = [];
    if (!empty($reservation['boarding_information'])) {
        $boarding_data = json_decode($reservation['boarding_information'], true);
        if (isset($boarding_data['tents']) && is_array($boarding_data['tents'])) {
            foreach ($boarding_data['tents'] as $boarding) {
                $tent_number = $boarding['tent_number'];
                if (isset($boarding['half_board_days']) && $boarding['half_board_days'] > 0) {
                    $boarding_configs[$tent_number]['half_board'] = intval($boarding['half_board_days']);
                }
                if (isset($boarding['full_board_days']) && $boarding['full_board_days'] > 0) {
                    $boarding_configs[$tent_number]['full_board'] = intval($boarding['full_board_days']);
                }
            }
        }
    }
    
    // Get exceptions for this reservation
    $exceptions = [];
    $exceptions_stmt = $pdo->prepare("SELECT * FROM reservation_exceptions WHERE reservation_id = ? ORDER BY assigned_tent_id");
    $exceptions_stmt->execute([$reservation['id']]);
    $exceptions = $exceptions_stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Group exceptions by tent ID
    $exceptions_by_tent = [];
    foreach ($exceptions as $exception) {
        if (!empty($exception['assigned_tent_id'])) {
            $tent_id = $exception['assigned_tent_id'];
            if (!isset($exceptions_by_tent[$tent_id])) {
                $exceptions_by_tent[$tent_id] = [];
            }
            $exceptions_by_tent[$tent_id][] = $exception;
        }
    }
    
    foreach ($assigned_tents as $index => $tent) {
        $tent_id = $tent['id'];
        $tent_type = $tent['tent_type'];
        $tent_number = $tent['tent_number'];
        $tent_spec_number = $index + 1; // Corresponds to "Tent 1", "Tent 2" in specifications
        
        // Get bed configuration for this tent
        $bed_config = $bed_configs[$tent_id]['bed_config'] ?? 'double'; // Default to double if not found
        $tent_spec_number_display = $bed_configs[$tent_id]['tent_number'] ?? '?';
        
        // Check if this tent has kids
        $kids_number = getKidsNumberForTent($pdo, $reservation['tent_specifications'], $tent_id);
        
        // Check if this tent has exceptions
        $tent_exceptions = $exceptions_by_tent[$tent_id] ?? [];
        $exception_count = count($tent_exceptions);
        
        if ($exception_count > 0) {
            // Calculate price with exceptions
            $bed_numbers = getBedNumbers($bed_config);
            $effective_beds = max(1, $bed_numbers - $exception_count);
            $effective_bed_config = getBedConfigFromNumbers($effective_beds);
            
            // Check if all beds are taken by exceptions (tent is free)
            if ($exception_count >= $bed_numbers) {
                // All beds are exceptions, tent is free
                $translated_tent_type = isset($translations[strtolower($tent_type)]) ? $translations[strtolower($tent_type)] : $tent_type;
                $translated_bed_config = isset($translations[strtolower($bed_config)]) ? $translations[strtolower($bed_config)] : $bed_config;
                $details[] = ($translations['tent'] ?? 'Tent') . " $tent_spec_number_display: $translated_tent_type - $translated_bed_config (" . ($translations['all_beds_are_exceptions'] ?? 'all beds are exceptions') . "): " . ($translations['free'] ?? 'FREE');
            } else if ($effective_beds == 1) {
                // Only 1 bed remaining, check if original tent was single
                if ($bed_numbers == 1) {
                    // Original tent was single, so it's free
                    $details[] = ($translations['tent'] ?? 'Tent') . " $tent_spec_number_display: $tent_type - $bed_config (" . ($translations['effective_single_due_to'] ?? 'effective: single due to') . " $exception_count " . ($translations['exception_s'] ?? 'exception(s)') . "): " . ($translations['free'] ?? 'FREE');
                } else {
                    // Original tent was larger (double/triple/quadruple), charge for single tent
                    $price_per_night = getTentPrice($pdo, $tent_type, 'single', $reservation['reservation_source'], $tariff_version_id);
                    if ($price_per_night !== null) {
                        if ($kids_number > 0) {
                            // Calculate kids pricing for single bed configuration
                            require_once 'kids_pricing_helper.php';
                            $kids_pricing = calculateKidsPricing($pdo, $tent_type, 'single', $reservation['reservation_source'], $kids_number, $reservation['nights']);
                            $discount_percentage = getKidsDiscountPercentage($pdo);
                            
                            // Calculate total occupied beds (exceptions + kids)
                            $total_occupied = $exception_count + $kids_number;
                            
                            if ($total_occupied >= $bed_numbers) {
                                // All beds are occupied by exceptions and kids
                                $translated_tent_type = isset($translations[strtolower($tent_type)]) ? $translations[strtolower($tent_type)] : $tent_type;
                                $translated_bed_config = isset($translations[strtolower($bed_config)]) ? $translations[strtolower($bed_config)] : $bed_config;
                                $details[] = ($translations['tent'] ?? 'Tent') . " $tent_spec_number_display: $translated_tent_type - $translated_bed_config (" . ($translations['effective_single_due_to'] ?? 'effective: single due to') . " $exception_count " . ($translations['exception_s'] ?? 'exception(s)') . ", " . ($translations['all_beds_occupied_by_exceptions_and_kids'] ?? 'all beds occupied by exceptions and kids') . "):";
                                
                                // Show kids pricing with formula
                                $tent_total_price = $kids_pricing['price_per_person'] * 1; // Single tent = 1 bed
                                $kids_price_per_person = $kids_pricing['kids_price_per_person'];
                                $details[] = "  - " . ($translations['kids_at_discount'] ?? 'Kids') . " ($kids_number " . ($translations['at_discount'] ?? 'at') . " $discount_percentage" . ($translations['percent'] ?? '%') . " " . ($translations['off'] ?? 'off') . "): " . $kids_pricing['kids_price'] . " TND";
                                $details[] = "    " . ($translations['calculation_formula'] ?? 'Calculation') . ": $tent_total_price TND " . ($translations['divided_by'] ?? '÷') . " 1 = " . $kids_pricing['price_per_person'] . " TND/" . ($translations['per_person'] ?? 'person') . " " . ($translations['times'] ?? '×') . " $kids_number " . ($translations['kids'] ?? 'kids') . " " . ($translations['times'] ?? '×') . " (1 " . ($translations['minus'] ?? '-') . " $discount_percentage" . ($translations['percent'] ?? '%') . ") = $kids_price_per_person TND/" . ($translations['per_person'] ?? 'person') . " " . ($translations['times'] ?? '×') . " $kids_number = " . $kids_pricing['kids_price'] . " TND";
                            } else {
                                $translated_tent_type = isset($translations[strtolower($tent_type)]) ? $translations[strtolower($tent_type)] : $tent_type;
                                $translated_bed_config = isset($translations[strtolower($bed_config)]) ? $translations[strtolower($bed_config)] : $bed_config;
                                $details[] = ($translations['tent'] ?? 'Tent') . " $tent_spec_number_display: $translated_tent_type - $translated_bed_config (" . ($translations['effective_single_due_to'] ?? 'effective: single due to') . " $exception_count " . ($translations['exception_s'] ?? 'exception(s)') . "):";
                                $details[] = "  - " . ($translations['adults'] ?? 'Adults') . " (0): 0.00 TND";
                                
                                // Show kids pricing with formula
                                $tent_total_price = $kids_pricing['price_per_person'] * 1; // Single tent = 1 bed
                                $kids_price_per_person = $kids_pricing['kids_price_per_person'];
                                $details[] = "  - " . ($translations['kids_at_discount'] ?? 'Kids') . " ($kids_number " . ($translations['at_discount'] ?? 'at') . " $discount_percentage" . ($translations['percent'] ?? '%') . " " . ($translations['off'] ?? 'off') . "): " . $kids_pricing['kids_price'] . " TND";
                                $details[] = "    " . ($translations['calculation_formula'] ?? 'Calculation') . ": $tent_total_price TND " . ($translations['divided_by'] ?? '÷') . " 1 = " . $kids_pricing['price_per_person'] . " TND/" . ($translations['per_person'] ?? 'person') . " " . ($translations['times'] ?? '×') . " $kids_number " . ($translations['kids'] ?? 'kids') . " " . ($translations['times'] ?? '×') . " (1 " . ($translations['minus'] ?? '-') . " $discount_percentage" . ($translations['percent'] ?? '%') . ") = $kids_price_per_person TND/" . ($translations['per_person'] ?? 'person') . " " . ($translations['times'] ?? '×') . " $kids_number = " . $kids_pricing['kids_price'] . " TND";
                                
                                $details[] = "  - " . ($translations['total'] ?? 'Total') . ": " . $kids_pricing['total_price'] . " TND";
                            }
                        } else {
                            $translated_tent_type = isset($translations[strtolower($tent_type)]) ? $translations[strtolower($tent_type)] : $tent_type;
                            $translated_bed_config = isset($translations[strtolower($bed_config)]) ? $translations[strtolower($bed_config)] : $bed_config;
                            $details[] = ($translations['tent'] ?? 'Tent') . " $tent_spec_number_display: $translated_tent_type - $translated_bed_config (" . ($translations['effective_single_due_to'] ?? 'effective: single due to') . " $exception_count " . ($translations['exception_s'] ?? 'exception(s)') . "): $price_per_night TND/" . ($translations['night'] ?? 'night') . " × " . $reservation['nights'] . " " . ($translations['nights'] ?? 'nights') . " = " . ($price_per_night * $reservation['nights']) . " TND";
                        }
                    } else {
                        $translated_tent_type = isset($translations[strtolower($tent_type)]) ? $translations[strtolower($tent_type)] : $tent_type;
                        $translated_bed_config = isset($translations[strtolower($bed_config)]) ? $translations[strtolower($bed_config)] : $bed_config;
                        $details[] = ($translations['tent'] ?? 'Tent') . " $tent_spec_number_display: $translated_tent_type - $translated_bed_config: " . ($translations['no_price_found'] ?? 'No price found');
                    }
                }
            } else {
                $price_per_night = getTentPrice($pdo, $tent_type, $effective_bed_config, $reservation['reservation_source'], $tariff_version_id);
                if ($price_per_night !== null) {
                    if ($kids_number > 0) {
                        // Calculate kids pricing for effective bed configuration
                        require_once 'kids_pricing_helper.php';
                        $kids_pricing = calculateKidsPricing($pdo, $tent_type, $effective_bed_config, $reservation['reservation_source'], $kids_number, $reservation['nights']);
                        $discount_percentage = getKidsDiscountPercentage($pdo);
                        $bed_capacity = getBedCapacity($effective_bed_config);
                        $adult_count = $bed_capacity - $kids_number;
                        
                        // Calculate total occupied beds (exceptions + kids)
                        $total_occupied = $exception_count + $kids_number;
                        
                        if ($total_occupied >= $bed_numbers) {
                            // All beds are occupied by exceptions and kids
                            $translated_tent_type = isset($translations[strtolower($tent_type)]) ? $translations[strtolower($tent_type)] : $tent_type;
                            $translated_bed_config = isset($translations[strtolower($bed_config)]) ? $translations[strtolower($bed_config)] : $bed_config;
                            $details[] = ($translations['tent'] ?? 'Tent') . " $tent_spec_number_display: $translated_tent_type - $translated_bed_config (" . ($translations['all_beds_occupied_by_exceptions_and_kids'] ?? 'all beds occupied by exceptions and kids') . "):";
                            
                            // Show kids pricing with formula
                            $tent_total_price = $kids_pricing['price_per_person'] * $bed_capacity;
                            $kids_price_per_person = $kids_pricing['kids_price_per_person'];
                            $details[] = "  - " . ($translations['kids_at_discount'] ?? 'Kids') . " ($kids_number " . ($translations['at_discount'] ?? 'at') . " $discount_percentage" . ($translations['percent'] ?? '%') . " " . ($translations['off'] ?? 'off') . "): " . $kids_pricing['kids_price'] . " TND";
                            $details[] = "    " . ($translations['calculation_formula'] ?? 'Calculation') . ": $tent_total_price TND " . ($translations['divided_by'] ?? '÷') . " $bed_capacity = " . $kids_pricing['price_per_person'] . " TND/" . ($translations['per_person'] ?? 'person') . " " . ($translations['times'] ?? '×') . " $kids_number " . ($translations['kids'] ?? 'kids') . " " . ($translations['times'] ?? '×') . " (1 " . ($translations['minus'] ?? '-') . " $discount_percentage" . ($translations['percent'] ?? '%') . ") = $kids_price_per_person TND/" . ($translations['per_person'] ?? 'person') . " " . ($translations['times'] ?? '×') . " $kids_number = " . $kids_pricing['kids_price'] . " TND";
                        } else {
                            $translated_tent_type = isset($translations[strtolower($tent_type)]) ? $translations[strtolower($tent_type)] : $tent_type;
                            $translated_bed_config = isset($translations[strtolower($bed_config)]) ? $translations[strtolower($bed_config)] : $bed_config;
                            $translated_effective_bed_config = isset($translations[strtolower($effective_bed_config)]) ? $translations[strtolower($effective_bed_config)] : $effective_bed_config;
                            $details[] = ($translations['tent'] ?? 'Tent') . " $tent_spec_number_display: $translated_tent_type - $translated_bed_config (" . ($translations['effective'] ?? 'effective') . ": $translated_effective_bed_config " . ($translations['due_to'] ?? 'due to') . " $exception_count " . ($translations['exception_s'] ?? 'exception(s)') . "):";
                            $details[] = "  - " . ($translations['adults'] ?? 'Adults') . " ($adult_count): " . $kids_pricing['adult_price'] . " TND";
                            
                            // Show kids pricing with formula
                            $tent_total_price = $kids_pricing['price_per_person'] * $bed_capacity;
                            $kids_price_per_person = $kids_pricing['kids_price_per_person'];
                            $details[] = "  - " . ($translations['kids_at_discount'] ?? 'Kids') . " ($kids_number " . ($translations['at_discount'] ?? 'at') . " $discount_percentage" . ($translations['percent'] ?? '%') . " " . ($translations['off'] ?? 'off') . "): " . $kids_pricing['kids_price'] . " TND";
                            $details[] = "    " . ($translations['calculation_formula'] ?? 'Calculation') . ": $tent_total_price TND " . ($translations['divided_by'] ?? '÷') . " $bed_capacity = " . $kids_pricing['price_per_person'] . " TND/" . ($translations['per_person'] ?? 'person') . " " . ($translations['times'] ?? '×') . " $kids_number " . ($translations['kids'] ?? 'kids') . " " . ($translations['times'] ?? '×') . " (1 " . ($translations['minus'] ?? '-') . " $discount_percentage" . ($translations['percent'] ?? '%') . ") = $kids_price_per_person TND/" . ($translations['per_person'] ?? 'person') . " " . ($translations['times'] ?? '×') . " $kids_number = " . $kids_pricing['kids_price'] . " TND";
                            
                            $details[] = "  - " . ($translations['total'] ?? 'Total') . ": " . $kids_pricing['total_price'] . " TND";
                        }
                    } else {
                        $translated_tent_type = isset($translations[strtolower($tent_type)]) ? $translations[strtolower($tent_type)] : $tent_type;
                        $translated_bed_config = isset($translations[strtolower($bed_config)]) ? $translations[strtolower($bed_config)] : $bed_config;
                        $translated_effective_bed_config = isset($translations[strtolower($effective_bed_config)]) ? $translations[strtolower($effective_bed_config)] : $effective_bed_config;
                        $details[] = ($translations['tent'] ?? 'Tent') . " $tent_spec_number_display: $translated_tent_type - $translated_bed_config (" . ($translations['effective'] ?? 'effective') . ": $translated_effective_bed_config " . ($translations['due_to'] ?? 'due to') . " $exception_count " . ($translations['exception_s'] ?? 'exception(s)') . "): $price_per_night TND/" . ($translations['night'] ?? 'night') . " × " . $reservation['nights'] . " " . ($translations['nights'] ?? 'nights') . " = " . ($price_per_night * $reservation['nights']) . " TND";
                    }
                } else {
                    $translated_tent_type = isset($translations[strtolower($tent_type)]) ? $translations[strtolower($tent_type)] : $tent_type;
                    $translated_bed_config = isset($translations[strtolower($bed_config)]) ? $translations[strtolower($bed_config)] : $bed_config;
                    $details[] = ($translations['tent'] ?? 'Tent') . " $tent_spec_number_display: $translated_tent_type - $translated_bed_config: " . ($translations['no_price_found'] ?? 'No price found');
                }
            }
            
            // Add exception details
            foreach ($tent_exceptions as $exception) {
                if (isset($exception['is_free']) && $exception['is_free']) {
                    $details[] = "  - " . ($translations['exception'] ?? 'Exception') . ": " . $exception['guest_name'] . " (" . $exception['exception_type'] . ") - " . ($translations['tent'] ?? 'Tent') . " #" . $tent_number . ": " . ($translations['free'] ?? 'FREE');
                } else {
                    $exception_price = floatval($exception['price_per_night'] ?? 0);
                    $details[] = "  - " . ($translations['exception'] ?? 'Exception') . ": " . $exception['guest_name'] . " (" . $exception['exception_type'] . ") - " . ($translations['tent'] ?? 'Tent') . " #" . $tent_number . ": $exception_price TND/" . ($translations['night'] ?? 'night') . " × " . $reservation['nights'] . " " . ($translations['nights'] ?? 'nights') . " = " . ($exception_price * $reservation['nights']) . " TND";
                }
            }
        } else {
            $price_per_night = getTentPrice($pdo, $tent_type, $bed_config, $reservation['reservation_source'], $tariff_version_id);
            if ($price_per_night !== null) {
                if ($kids_number > 0) {
                    // Calculate kids pricing
                    require_once 'kids_pricing_helper.php';
                    $kids_pricing = calculateKidsPricing($pdo, $tent_type, $bed_config, $reservation['reservation_source'], $kids_number, $reservation['nights']);
                    $discount_percentage = getKidsDiscountPercentage($pdo);
                    $bed_capacity = getBedCapacity($bed_config);
                    $adult_count = $bed_capacity - $kids_number;
                    
                    $translated_tent_type = isset($translations[strtolower($tent_type)]) ? $translations[strtolower($tent_type)] : $tent_type;
                    $translated_bed_config = isset($translations[strtolower($bed_config)]) ? $translations[strtolower($bed_config)] : $bed_config;
                    $details[] = ($translations['tent'] ?? 'Tent') . " $tent_spec_number_display: $translated_tent_type - $translated_bed_config:";
                    $details[] = "  - " . ($translations['adults'] ?? 'Adults') . " ($adult_count): " . $kids_pricing['adult_price'] . " TND";
                    
                    // Show kids pricing with formula
                    $tent_total_price = $kids_pricing['price_per_person'] * $bed_capacity;
                    $kids_price_per_person = $kids_pricing['kids_price_per_person'];
                    $details[] = "  - " . ($translations['kids_at_discount'] ?? 'Kids') . " ($kids_number " . ($translations['at_discount'] ?? 'at') . " $discount_percentage" . ($translations['percent'] ?? '%') . " " . ($translations['off'] ?? 'off') . "): " . $kids_pricing['kids_price'] . " TND";
                    $details[] = "    " . ($translations['calculation_formula'] ?? 'Calculation') . ": $tent_total_price TND " . ($translations['divided_by'] ?? '÷') . " $bed_capacity = " . $kids_pricing['price_per_person'] . " TND/" . ($translations['per_person'] ?? 'person') . " " . ($translations['times'] ?? '×') . " $kids_number " . ($translations['kids'] ?? 'kids') . " " . ($translations['times'] ?? '×') . " (1 " . ($translations['minus'] ?? '-') . " $discount_percentage" . ($translations['percent'] ?? '%') . ") = $kids_price_per_person TND/" . ($translations['per_person'] ?? 'person') . " " . ($translations['times'] ?? '×') . " $kids_number = " . $kids_pricing['kids_price'] . " TND";
                    
                    $details[] = "  - " . ($translations['total'] ?? 'Total') . ": " . $kids_pricing['total_price'] . " TND";
                } else {
                    $translated_tent_type = isset($translations[strtolower($tent_type)]) ? $translations[strtolower($tent_type)] : $tent_type;
                    $translated_bed_config = isset($translations[strtolower($bed_config)]) ? $translations[strtolower($bed_config)] : $bed_config;
                    $details[] = ($translations['tent'] ?? 'Tent') . " $tent_spec_number_display: $translated_tent_type - $translated_bed_config: $price_per_night TND/" . ($translations['night'] ?? 'night') . " × " . $reservation['nights'] . " " . ($translations['nights'] ?? 'nights') . " = " . ($price_per_night * $reservation['nights']) . " TND";
                }
            } else {
                $translated_tent_type = isset($translations[strtolower($tent_type)]) ? $translations[strtolower($tent_type)] : $tent_type;
                $translated_bed_config = isset($translations[strtolower($bed_config)]) ? $translations[strtolower($bed_config)] : $bed_config;
                $details[] = ($translations['tent'] ?? 'Tent') . " $tent_spec_number_display: $translated_tent_type - $translated_bed_config: " . ($translations['no_price_found'] ?? 'No price found');
            }
        }
        
        // Add boarding details (kids don't get boarding discounts)
        $boarding_config = $boarding_configs[$tent_spec_number_display] ?? [];
        
        if (isset($boarding_config['half_board']) && $boarding_config['half_board'] > 0) {
            $half_board_price = getBoardingPrice($pdo, $reservation['reservation_source'], $tent_type, $bed_config, 'half_board', $tariff_version_id);
            
            // Calculate per-person boarding with the same logic as in pricing calculation
            require_once 'kids_pricing_helper.php';
            $bed_capacity = getBedCapacity($bed_config);
            $exception_count = count($tent_exceptions);
            $effective_capacity = max(0, $bed_capacity - $exception_count);
            $per_person_boarding = $bed_capacity > 0 ? ($half_board_price / $bed_capacity) : 0;
            $kids_discount_percentage = getKidsDiscountPercentage($pdo);
            $kids_count_boarding = min($kids_number, $effective_capacity);
            $adult_count_boarding = max(0, $effective_capacity - $kids_count_boarding);
            $per_day_boarding_total = ($adult_count_boarding * $per_person_boarding) + ($kids_count_boarding * $per_person_boarding * (1 - ($kids_discount_percentage / 100)));
            $half_board_total = $per_day_boarding_total * $boarding_config['half_board'];
            
            $details[] = "  - " . ($translations['half_board'] ?? 'Half Board') . ": " . number_format($per_day_boarding_total, 0) . " TND/" . ($translations['night'] ?? 'night') . " × " . $boarding_config['half_board'] . " " . ($boarding_config['half_board'] === 1 ? ($translations['night'] ?? 'night') : ($translations['nights'] ?? 'nights')) . " = " . number_format($half_board_total, 0) . " TND";
        }
        
        if (isset($boarding_config['full_board']) && $boarding_config['full_board'] > 0) {
            $full_board_price = getBoardingPrice($pdo, $reservation['reservation_source'], $tent_type, $bed_config, 'full_board', $tariff_version_id);
            
            // Calculate per-person boarding with the same logic as in pricing calculation
            require_once 'kids_pricing_helper.php';
            $bed_capacity = getBedCapacity($bed_config);
            $exception_count = count($tent_exceptions);
            $effective_capacity = max(0, $bed_capacity - $exception_count);
            $per_person_boarding = $bed_capacity > 0 ? ($full_board_price / $bed_capacity) : 0;
            $kids_discount_percentage = getKidsDiscountPercentage($pdo);
            $kids_count_boarding = min($kids_number, $effective_capacity);
            $adult_count_boarding = max(0, $effective_capacity - $kids_count_boarding);
            $per_day_boarding_total = ($adult_count_boarding * $per_person_boarding) + ($kids_count_boarding * $per_person_boarding * (1 - ($kids_discount_percentage / 100)));
            $full_board_total = $per_day_boarding_total * $boarding_config['full_board'];
            
            $details[] = "  - " . ($translations['full_board'] ?? 'Full Board') . ": " . number_format($per_day_boarding_total, 0) . " TND/" . ($translations['night'] ?? 'night') . " × " . $boarding_config['full_board'] . " " . ($boarding_config['full_board'] === 1 ? ($translations['night'] ?? 'night') : ($translations['nights'] ?? 'nights')) . " = " . number_format($full_board_total, 0) . " TND";
        }
    }
    
    return $details;
}

/**
 * Validate tent specifications format
 * @param string $tent_specifications Tent specifications string
 * @return array Validation result with status and details
 */
function validateTentSpecifications($tent_specifications) {
    // Allow empty tent specifications for day visitors
    if (empty($tent_specifications)) {
        return [
            'valid' => true, 
            'valid_specs' => [], 
            'invalid_specs' => [], 
            'total_tents' => 0,
            'message' => 'No tents required (day visitor)'
        ];
    }
    
    $specs = explode(', ', $tent_specifications);
    $valid_specs = [];
    $invalid_specs = [];
    
    foreach ($specs as $index => $spec) {
        $spec = trim($spec);
        if (preg_match('/Tent\s*(\d+):\s*(\w+)\s*-\s*(\w+)/', $spec, $matches)) {
            $tent_number = $matches[1];
            $tent_type = $matches[2];
            $bed_config = $matches[3];
            
            // Validate tent type
            if (!in_array($tent_type, ['ROYAL', 'NORMAL'])) {
                $invalid_specs[] = "Tent $tent_number: Invalid tent type '$tent_type'";
                continue;
            }
            
            // Validate bed configuration
            if (!in_array($bed_config, ['single', 'double', 'triple', 'quadruple'])) {
                $invalid_specs[] = "Tent $tent_number: Invalid bed configuration '$bed_config'";
                continue;
            }
            
            $valid_specs[] = [
                'tent_number' => $tent_number,
                'tent_type' => $tent_type,
                'bed_config' => $bed_config,
                'spec' => $spec
            ];
        } else {
            $invalid_specs[] = "Spec $index: Could not parse '$spec'";
        }
    }
    
    return [
        'valid' => empty($invalid_specs),
        'valid_specs' => $valid_specs,
        'invalid_specs' => $invalid_specs,
        'total_tents' => count($valid_specs),
        'message' => empty($invalid_specs) ? 'All tent specifications are valid' : 'Some tent specifications are invalid'
    ];
}

/**
 * Get driver price from tariff table for specific version
 * @param PDO $pdo Database connection
 * @param int $tariff_version_id Tariff version ID
 * @return float Driver price
 */
function getDriverPrice($pdo, $tariff_version_id = null) {
    if ($tariff_version_id === null) {
        $tariff_version_id = getCurrentTariffVersion($pdo);
    }
    $stmt = $pdo->prepare("SELECT price_per_unit FROM service_tariff_prices WHERE service_type = 'driver' AND tariff_version_id = ? AND is_active = 1 LIMIT 1");
    $stmt->execute([$tariff_version_id]);
    $result = $stmt->fetch();
    return $result ? floatval($result['price_per_unit']) : 80; // default 80
}

/**
 * Get guide price from tariff table for specific version
 * @param PDO $pdo Database connection
 * @param int $tariff_version_id Tariff version ID
 * @return float Guide price
 */
function getGuidePrice($pdo, $tariff_version_id = null) {
    if ($tariff_version_id === null) {
        $tariff_version_id = getCurrentTariffVersion($pdo);
    }
    $stmt = $pdo->prepare("SELECT price_per_unit FROM service_tariff_prices WHERE service_type = 'guide' AND tariff_version_id = ? AND is_active = 1 LIMIT 1");
    $stmt->execute([$tariff_version_id]);
    $result = $stmt->fetch();
    return $result ? floatval($result['price_per_unit']) : 80; // default 80
}

/**
 * Get car 4x4 price from tariff table for specific version based on usage period
 * @param PDO $pdo Database connection
 * @param int $car_days Number of car days
 * @param int $tariff_version_id Tariff version ID
 * @return float Car 4x4 price
 */
function getCar4x4Price($pdo, $car_days = 1, $tariff_version_id = null) {
    if ($tariff_version_id === null) {
        $tariff_version_id = getCurrentTariffVersion($pdo);
    }
    
    // Determine which price to use based on car days
    $service_type = ($car_days == 1) ? 'car_4x4_1day' : 'car_4x4_multiday';
    
    $stmt = $pdo->prepare("SELECT price_per_unit FROM service_tariff_prices WHERE service_type = ? AND tariff_version_id = ? AND is_active = 1 LIMIT 1");
    $stmt->execute([$service_type, $tariff_version_id]);
    $result = $stmt->fetch();
    
    if ($result) {
        return floatval($result['price_per_unit']);
    }
    
    // Fallback to old car_4x4 price if new prices don't exist
    $stmt = $pdo->prepare("SELECT price_per_unit FROM service_tariff_prices WHERE service_type = 'car_4x4' AND tariff_version_id = ? AND is_active = 1 LIMIT 1");
    $stmt->execute([$tariff_version_id]);
    $result = $stmt->fetch();
    
    return $result ? floatval($result['price_per_unit']) : 150; // default 150
}

function getBoardingPrice($pdo, $reservation_source, $tent_type, $bed_configuration, $boarding_type, $tariff_version_id = null) {
    $query = "SELECT price_per_night FROM boarding_prices 
              WHERE reservation_source = ? 
              AND tent_type = ? 
              AND bed_configuration = ? 
              AND boarding_type = ?";
    $params = [$reservation_source, $tent_type, $bed_configuration, $boarding_type];
    
    if ($tariff_version_id) {
        $query .= " AND tariff_version_id = ?";
        $params[] = $tariff_version_id;
    } else {
        $query .= " AND tariff_version_id IS NULL";
    }
    
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    
    return $result ? floatval($result['price_per_night']) : 0.00;
}

function getAllBoardingPrices($pdo, $tariff_version_id = null) {
    $query = "SELECT * FROM boarding_prices";
    $params = [];
    
    if ($tariff_version_id) {
        $query .= " WHERE tariff_version_id = ?";
        $params[] = $tariff_version_id;
    } else {
        $query .= " WHERE tariff_version_id IS NULL";
    }
    
    $query .= " ORDER BY reservation_source, tent_type, bed_configuration, boarding_type";
    
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function updateBoardingPrice($pdo, $id, $price, $tariff_version_id = null) {
    $query = "UPDATE boarding_prices SET price_per_night = ?, updated_at = NOW() WHERE id = ?";
    $params = [$price, $id];
    
    if ($tariff_version_id) {
        $query .= " AND tariff_version_id = ?";
        $params[] = $tariff_version_id;
    }
    
    $stmt = $pdo->prepare($query);
    return $stmt->execute($params);
}

/**
 * Calculate car pricing correctly by processing each car individually
 * @param PDO $pdo Database connection
 * @param int $reservation_id Reservation ID
 * @param int $tariff_version_id Tariff version ID
 * @return float Total car price
 */
function calculateCarPricingCorrectly($pdo, $reservation_id, $tariff_version_id = null) {
    if ($tariff_version_id === null) {
        $tariff_version_id = getCurrentTariffVersion($pdo);
    }
    
    $total_car_price = 0;
    
    // Get all cars assigned to this reservation with their individual dates
    $stmt = $pdo->prepare("SELECT start_date, end_date FROM reservation_cars WHERE reservation_id = ?");
    $stmt->execute([$reservation_id]);
    $assigned_cars = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    foreach ($assigned_cars as $car) {
        $start_date = new DateTime($car['start_date']);
        $end_date = new DateTime($car['end_date']);
        $car_nights = $end_date->diff($start_date)->days;
        
        // Get price for this specific car's night count
        $car_price_per_night = getCar4x4Price($pdo, $car_nights, $tariff_version_id);
        
        // Calculate price for this car: nights × price for that night count
        $car_total = $car_price_per_night * $car_nights;
        $total_car_price += $car_total;
    }
    return $total_car_price;
}
?> 