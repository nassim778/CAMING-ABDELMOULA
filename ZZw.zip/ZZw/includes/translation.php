<?php
if (!function_exists('t')) {
    $lang = $_SESSION['lang'] ?? 'en';
    $trans = [];
    if ($lang === 'fr' && file_exists(__DIR__ . '/../languages/fr.php')) {
        $trans = include __DIR__ . '/../languages/fr.php';
    }
    function t($key, $default) {
        global $trans;
        return $trans[$key] ?? $default;
    }
} 