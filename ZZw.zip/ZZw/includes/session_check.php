<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/session_config.php';

// Verify user agent hasn't changed (optimized)
if (!verify_user_agent()) {
    header('Location: index.php?error=security_violation');
    exit();
}

// Validate session security (optimized)
if (!validate_session_security()) {
    header('Location: index.php?error=session_expired');
    exit();
}

// Check if user exists and is active in database (optimized with caching)
if (isset($_SESSION['user_logged_in']) && $_SESSION['user_logged_in'] === true) {
    // Only check database every 5 minutes to improve performance
    if (!isset($_SESSION['last_db_check']) || 
        (time() - $_SESSION['last_db_check']) > 300) {
        
        $stmt = $pdo->prepare("SELECT is_active FROM users WHERE id = ?");
        $stmt->execute([$_SESSION['user_id']]);
        $user = $stmt->fetch();
        
        if (!$user || $user['is_active'] != 1) {
            secure_logout();
            header('Location: index.php?error=inactive');
            exit();
        }
        
        // Cache the database check result
        $_SESSION['last_db_check'] = time();
        $_SESSION['user_active'] = true;
    }
} else {
    // Not logged in, redirect to login
    header('Location: index.php?error=not_logged_in');
    exit();
}
?> 