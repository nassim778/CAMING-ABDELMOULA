<div class="form-row-pair">
    <!-- Reservation Details -->
    <div class="form-section">
        <h3>Reservation Details</h3>
        <div class="form-row">
            <div class="form-group">
                <label for="check_in_date">Check-in Date *</label>
                <input type="date" id="check_in_date" name="check_in_date" required value="<?php echo htmlspecialchars($reservation['check_in_date']); ?>">
            </div>
            <div class="form-group">
                <label for="check_out_date">Check-out Date *</label>
                <input type="date" id="check_out_date" name="check_out_date" required value="<?php echo htmlspecialchars($reservation['check_out_date']); ?>">
            </div>
        </div>
        <!-- Cars Section -->
        <div class="form-row">
            <div class="form-group">
                <label for="cars_4x4">Number of Cars</label>
                <input type="number" id="cars_4x4" name="cars_4x4" value="<?php echo htmlspecialchars($reservation['cars_4x4']); ?>" min="0" onchange="toggleCarFields();fetchAvailableResources();">
            </div>
            <div class="form-group" id="car_period_group" style="<?php echo ($reservation['cars_4x4'] > 0) ? '' : 'display:none;'; ?>">
                <label>Car Usage Period</label>
                <div style="display:flex;gap:8px;">
                    <input type="date" id="car_start_date" name="car_start_date" value="<?php echo htmlspecialchars($reservation['car_start_date'] ?? $reservation['check_in_date']); ?>" onchange="updateCarDays();fetchAvailableResources();">
                    <span>to</span>
                    <input type="date" id="car_end_date" name="car_end_date" value="<?php echo htmlspecialchars($reservation['car_end_date'] ?? $reservation['check_out_date']); ?>" onchange="updateCarDays();fetchAvailableResources();">
                </div>
                <small>If left blank, defaults to reservation period.</small>
            </div>
            <div class="form-group" id="car_days_group" style="<?php echo ($reservation['cars_4x4'] > 0) ? '' : 'display:none;'; ?>">
                <label for="car_days">Car Days</label>
                <input type="number" id="car_days" name="car_days" value="<?php echo htmlspecialchars($reservation['car_days']); ?>" min="0" readonly>
            </div>
        </div>
        <!-- Drivers Section -->
        <div class="form-row">
            <div class="form-group">
                <label for="staff_drivers">Number of Drivers</label>
                <input type="number" id="staff_drivers" name="staff_drivers" value="<?php echo htmlspecialchars($reservation['staff_drivers']); ?>" min="0" onchange="toggleDriverFields();fetchAvailableResources();">
            </div>
            <div class="form-group" id="driver_period_group" style="<?php echo ($reservation['staff_drivers'] > 0) ? '' : 'display:none;'; ?>">
                <label>Driver Usage Period</label>
                <div style="display:flex;gap:8px;">
                    <input type="date" id="driver_start_date" name="driver_start_date" value="<?php echo htmlspecialchars($reservation['driver_start_date'] ?? $reservation['check_in_date']); ?>" onchange="updateDriverDays();fetchAvailableResources();">
                    <span>to</span>
                    <input type="date" id="driver_end_date" name="driver_end_date" value="<?php echo htmlspecialchars($reservation['driver_end_date'] ?? $reservation['check_out_date']); ?>" onchange="updateDriverDays();fetchAvailableResources();">
                </div>
                <small>If left blank, defaults to reservation period.</small>
            </div>
            <div class="form-group" id="driver_days_group" style="<?php echo ($reservation['staff_drivers'] > 0) ? '' : 'display:none;'; ?>">
                <label for="driver_days">Driver Days</label>
                <input type="number" id="driver_days" name="driver_days" value="<?php echo htmlspecialchars($reservation['driver_days']); ?>" min="0" readonly>
            </div>
        </div>
        <!-- Guides Section -->
        <div class="form-row">
            <div class="form-group">
                <label for="staff_guides">Number of Guides</label>
                <input type="number" id="staff_guides" name="staff_guides" value="<?php echo htmlspecialchars($reservation['staff_guides']); ?>" min="0" onchange="toggleGuideFields();fetchAvailableResources();">
            </div>
            <div class="form-group" id="guide_period_group" style="<?php echo ($reservation['staff_guides'] > 0) ? '' : 'display:none;'; ?>">
                <label>Guide Usage Period</label>
                <div style="display:flex;gap:8px;">
                    <input type="date" id="guide_start_date" name="guide_start_date" value="<?php echo htmlspecialchars($reservation['guide_start_date'] ?? $reservation['check_in_date']); ?>" onchange="updateGuideDays();fetchAvailableResources();">
                    <span>to</span>
                    <input type="date" id="guide_end_date" name="guide_end_date" value="<?php echo htmlspecialchars($reservation['guide_end_date'] ?? $reservation['check_out_date']); ?>" onchange="updateGuideDays();fetchAvailableResources();">
                </div>
                <small>If left blank, defaults to reservation period.</small>
            </div>
            <div class="form-group" id="guide_days_group" style="<?php echo ($reservation['staff_guides'] > 0) ? '' : 'display:none;'; ?>">
                <label for="guide_days">Guide Days</label>
                <input type="number" id="guide_days" name="guide_days" value="<?php echo htmlspecialchars($reservation['guide_days']); ?>" min="0" readonly>
            </div>
        </div>
        <div id="resourceSelection"></div>
    </div>
</div>

<div class="form-section">
    <h3>Services</h3>
    <div class="services-grid">
        <?php foreach ($services as $service): ?>
        <div class="service-item">
            <div class="service-header">
                <label>
                    <input type="checkbox" name="services[<?php echo $service['id']; ?>][selected]" value="1" <?php if (!empty($services_data[$service['id']]['selected'])) echo 'checked'; ?>>
                    <?php echo htmlspecialchars($service['name']); ?>
                </label>
            </div>
            <div class="service-price">
                <label>Price (TND)</label>
                <input type="number" name="services[<?php echo $service['id']; ?>][price]" value="<?php echo isset($services_data[$service['id']]['price']) ? htmlspecialchars($services_data[$service['id']]['price']) : $service['price']; ?>" step="0.01" min="0">
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>

<div class="form-row-pair">
    <div class="form-section">
        <h3>Accommodation</h3>
        <div class="form-row">
            <div class="form-group">
                <label for="number_of_tents">Number of Tents</label>
                <input type="number" id="number_of_tents" name="number_of_tents" value="<?php echo htmlspecialchars($reservation['number_of_tents']); ?>" min="0" max="100" onchange="updateTentRows()">
            </div>
        </div>
        <div id="tent_rows_container"></div>
        <button type="button" onclick="addTentRow()">Add Tent</button>
        <button type="button" onclick="removeTentRow()">Remove Tent</button>
        <input type="hidden" id="tent_specifications" name="tent_specifications" value="<?php echo htmlspecialchars($reservation['tent_specifications']); ?>">
    </div>
    <div class="form-section">
        <h3>Payment</h3>
        <div class="form-row">
            <div class="form-group">
                <label for="payment_cash">Cash Payment (TND)</label>
                <input type="number" id="payment_cash" name="payment_cash" value="<?php echo htmlspecialchars($reservation['payment_cash']); ?>" min="0" step="0.01">
            </div>
            <div class="form-group">
                <label for="payment_bank_check">Bank Check Payment (TND)</label>
                <input type="number" id="payment_bank_check" name="payment_bank_check" value="<?php echo htmlspecialchars($reservation['payment_bank_check']); ?>" min="0" step="0.01">
            </div>
            <div class="form-group">
                <label for="payment_transfer">Transfer Payment (TND)</label>
                <input type="number" id="payment_transfer" name="payment_transfer" value="<?php echo htmlspecialchars($reservation['payment_transfer'] ?? '0'); ?>" min="0" step="0.01">
            </div>
        </div>
        <div class="form-group">
            <label for="payment_status">Payment Status</label>
            <select id="payment_status" name="payment_status">
                <option value="pending" <?php if ($reservation['payment_status'] === 'pending') echo 'selected'; ?>>Pending</option>
                <option value="partial" <?php if ($reservation['payment_status'] === 'partial') echo 'selected'; ?>>Partial</option>
                <option value="paid" <?php if ($reservation['payment_status'] === 'paid') echo 'selected'; ?>>Paid</option>
            </select>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label for="discount_type">Discount Type</label>
                <select id="discount_type" name="discount_type" onchange="toggleDiscountFields()">
                    <option value="none" <?php if ($reservation['discount_type'] === 'none') echo 'selected'; ?>>None</option>
                    <option value="percent" <?php if ($reservation['discount_type'] === 'percent') echo 'selected'; ?>>Percentage (%)</option>
                    <option value="amount" <?php if ($reservation['discount_type'] === 'amount') echo 'selected'; ?>>Amount (TND)</option>
                </select>
            </div>
            <div class="form-group" id="discount_percent_group" style="display: <?php echo $reservation['discount_type'] === 'percent' ? '' : 'none'; ?>;">
                <label for="discount_percent">Discount (%)</label>
                <input type="number" step="0.01" min="0" max="100" id="discount_percent" name="discount_percent" value="<?php echo htmlspecialchars($reservation['discount_type'] === 'percent' ? $reservation['discount_value'] : ''); ?>">
            </div>
            <div class="form-group" id="discount_amount_group" style="display: <?php echo $reservation['discount_type'] === 'amount' ? '' : 'none'; ?>;">
                <label for="discount_amount">Discount (TND)</label>
                <input type="number" step="0.01" min="0" id="discount_amount" name="discount_amount" value="<?php echo htmlspecialchars($reservation['discount_type'] === 'amount' ? $reservation['discount_value'] : ''); ?>">
            </div>
        </div>
    </div>
    <div class="form-section">
        <h3>Additional Information</h3>
        <div class="form-group">
            <label for="notes">Notes</label>
            <textarea id="notes" name="notes" rows="4"><?php echo htmlspecialchars($reservation['notes']); ?></textarea>
        </div>
    </div>
</div> 

<script>
let tentRowCount = <?php echo (int)($reservation['number_of_tents'] ?? 1); ?>;
let assignedTentIds = <?php echo json_encode(array_values($assigned_tent_ids ?? [])); ?>;

function updateTentRows() {
    const num = parseInt(document.getElementById('number_of_tents').value) || 1;
    tentRowCount = num;
    renderTentRows();
}

function addTentRow() {
    tentRowCount++;
    document.getElementById('number_of_tents').value = tentRowCount;
    renderTentRows();
}

function removeTentRow() {
    if (tentRowCount > 0) {
        tentRowCount--;
        document.getElementById('number_of_tents').value = tentRowCount;
        renderTentRows();
    }
}

function renderTentRows() {
    const container = document.getElementById('tent_rows_container');
    container.innerHTML = '';
    for (let i = 1; i <= tentRowCount; i++) {
        const tentType = '';
        const beds = '';
        const tentId = assignedTentIds[i-1] || '';
        container.innerHTML += `
        <div class="tent-row" data-tent-index="${i}">
            <h4>Tent ${i}</h4>
            <div class="form-row">
                <div class="form-group">
                    <label for="tent_${i}_type">Tent Type</label>
                    <select id="tent_${i}_type" name="tent_${i}_type" onchange="fetchAvailableTentNumbers(${i})">
                        <option value=""><?php echo t('select_type', 'Select Type'); ?></option>
                        <option value="NORMAL"><?php echo t('normal', 'NORMAL'); ?></option>
                        <option value="ROYAL"><?php echo t('royal', 'ROYAL'); ?></option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="tent_${i}_beds"><?php echo t('bed_configuration', 'Bed Configuration'); ?></label>
                    <select id="tent_${i}_beds" name="tent_${i}_beds" onchange="updateTentSpecifications()">
                        <option value=""><?php echo t('select_beds', 'Select Beds'); ?></option>
                        <option value="single"><?php echo t('single_bed', 'Single Bed'); ?></option>
                        <option value="double"><?php echo t('double_bed', 'Double Bed'); ?></option>
                        <option value="triple"><?php echo t('triple_bed', 'Triple Bed'); ?></option>
                        <option value="quadruple"><?php echo t('quadruple_bed', 'Quadruple Bed'); ?></option>
                    </select>
                </div>
                <div class="form-group" id="tent_${i}_number_group">
                    <select name="tent_numbers[]" id="tent_${i}_number" disabled>
                        <option value="">Loading tents...</option>
                    </select>
                    <input type="hidden" name="tent_types[]" id="tent_types_${i}" value="">
                </div>
            </div>
        </div>`;
    }
    populateTentRowsFromSpecs();
    updateTentSpecifications();
    for (let i = 1; i <= tentRowCount; i++) {
        fetchAvailableTentNumbers(i, assignedTentIds[i-1] || null);
    }
    checkTentDropdowns();
}

function fetchAvailableTentNumbers(tentIndex, assignedTentId = null) {
    const type = document.getElementById(`tent_${tentIndex}_type`).value;
    const check_in = document.getElementById('check_in_date').value;
    const check_out = document.getElementById('check_out_date').value;
    const selectEl = document.getElementById(`tent_${tentIndex}_number`);
    if (!type || !check_in || !check_out) {
        if (selectEl) {
            selectEl.innerHTML = '<option value=""><?php echo t("select_tent_type_and_dates", "Select tent type and dates"); ?></option>';
            selectEl.disabled = true;
        }
        updateTentSpecifications();
        checkTentDropdowns();
        return;
    }
    fetch(`add_reservation.php?fetch_tents=1&tent_type=${type}&start_date=${check_in}&end_date=${check_out}&edit_reservation_id=<?php echo $reservation['id']; ?>`)
        .then(res => res.json())
        .then(data => {
            let html = '<option value=""><?php echo t("select_tent", "Select Tent"); ?></option>';
            let foundAssigned = false;
            if (data.tents && data.tents.length > 0) {
                data.tents.forEach(tent => {
                    let selected = '';
                    if (assignedTentIds[tentIndex-1] && assignedTentIds[tentIndex-1] == tent.id) {
                        selected = ' selected';
                        foundAssigned = true;
                    }
                    html += `<option value="${tent.id}"${selected}>${tent.tent_number}</option>`;
                });
            }
            if (assignedTentIds[tentIndex-1] && !foundAssigned) {
                let tentNum = assignedTentIds[tentIndex-1];
                html += `<option value="${assignedTentIds[tentIndex-1]}" selected disabled>${tentNum} (<?php echo t("unavailable", "Unavailable"); ?>)</option>`;
            }
            if (selectEl) {
                selectEl.innerHTML = html;
                selectEl.disabled = false;
            }
            updateTentSpecifications();
            checkTentDropdowns();
        })
        .catch(() => {
            if (selectEl) {
                selectEl.innerHTML = '<option value=""><?php echo t("error_loading_tents", "Error loading tents"); ?></option>';
                selectEl.disabled = true;
            }
            checkTentDropdowns();
        });
}

function updateTentSpecifications() {
    let specs = [];
    for (let i = 1; i <= tentRowCount; i++) {
        const type = document.getElementById(`tent_${i}_type`).value;
        const beds = document.getElementById(`tent_${i}_beds`).value;
        const tentNumberSelect = document.getElementById(`tent_${i}_number`);
        const tentTypeInput = document.getElementById(`tent_types_${i}`);
        let tentNumberText = '';
        if (tentNumberSelect && tentNumberSelect.value) {
            tentNumberText = ` (Tent #${tentNumberSelect.options[tentNumberSelect.selectedIndex].text})`;
        }
        if (type && beds && tentNumberSelect && tentNumberSelect.value && tentTypeInput && tentTypeInput.value) {
            specs.push(`Tent ${i}: ${tentTypeInput.value} - ${beds}${tentNumberText}`);
        }
    }
    document.getElementById('tent_specifications').value = specs.join(', ');
}

function populateTentRowsFromSpecs() {
    const tentSpecs = document.getElementById('tent_specifications').value;
    if (!tentSpecs) return;
    const specsArr = tentSpecs.split(', ');
    for (let idx = 0; idx < specsArr.length; idx++) {
        const spec = specsArr[idx];
        const match = spec.match(/Tent (\d+): (\w+) - (\w+)(?:\s*\(Tent #(\d+)\))?/);
        if (match) {
            const tentNum = parseInt(match[1]);
            const type = match[2];
            const beds = match[3];
            const tentTypeSelect = document.getElementById(`tent_${tentNum}_type`);
            const bedsSelect = document.getElementById(`tent_${tentNum}_beds`);
            const tentTypeInput = document.getElementById(`tent_types_${tentNum}`);
            if (tentTypeSelect) tentTypeSelect.value = type;
            if (bedsSelect) bedsSelect.value = beds;
            if (tentTypeInput) tentTypeInput.value = type;
            fetchAvailableTentNumbers(tentNum, assignedTentIds[tentNum-1] || null);
        }
    }
}

function checkTentDropdowns() {
    // Allow reservations without tents (day visitors)
    // Only check if tents are properly configured when they are actually selected
    const form = document.querySelector('form');
    const submitBtn = form ? form.querySelector('button[type="submit"]') : null;
    
    // If no tents are configured, allow submission (day visitor)
    let hasTentConfigurations = false;
    for (let i = 1; i <= tentRowCount; i++) {
        const typeSelect = document.getElementById(`tent_${i}_type`);
        const bedsSelect = document.getElementById(`tent_${i}_beds`);
        const numberSelect = document.getElementById(`tent_${i}_number`);
        
        if (typeSelect && typeSelect.value && bedsSelect && bedsSelect.value && numberSelect && numberSelect.value) {
            hasTentConfigurations = true;
            break;
        }
    }
    
    // If no tents are configured, allow submission
    if (!hasTentConfigurations) {
        if (submitBtn) submitBtn.disabled = false;
        return;
    }
    
    // If tents are configured, ensure they are complete
    let allReady = true;
    for (let i = 1; i <= tentRowCount; i++) {
        const typeSelect = document.getElementById(`tent_${i}_type`);
        const bedsSelect = document.getElementById(`tent_${i}_beds`);
        const numberSelect = document.getElementById(`tent_${i}_number`);
        
        // If any tent field is filled, all must be filled for that tent
        if (typeSelect && typeSelect.value) {
            if (!bedsSelect || !bedsSelect.value || !numberSelect || !numberSelect.value) {
                allReady = false;
                break;
            }
        }
    }
    
    if (submitBtn) submitBtn.disabled = !allReady;
}

document.addEventListener('DOMContentLoaded', function() {
    renderTentRows();
});
</script> 