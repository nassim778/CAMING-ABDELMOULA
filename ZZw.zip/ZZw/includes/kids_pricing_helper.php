<?php
require_once __DIR__ . '/../config/database.php';

/**
 * Calculate kids pricing for a tent
 * @param PDO $pdo Database connection
 * @param string $tent_type Tent type (ROYAL, NORMAL)
 * @param string $bed_configuration Bed configuration (single, double, triple, quadruple)
 * @param string $reservation_source Reservation source (individual, agency)
 * @param int $kids_number Number of kids
 * @param int $nights Number of nights
 * @return array Array with adult_price, kids_price, and total_price
 */
function calculateKidsPricing($pdo, $tent_type, $bed_configuration, $reservation_source, $kids_number, $nights) {
    // Get the current tariff version
    $stmt = $pdo->query("SELECT id FROM tariff_versions WHERE is_active = 1");
    $current_version = $stmt->fetch();
    
    if (!$current_version) {
        return ['adult_price' => 0, 'kids_price' => 0, 'total_price' => 0];
    }
    
    // Get tent price per night
    $stmt = $pdo->prepare("SELECT price_per_night FROM tariff_prices WHERE tariff_version_id = ? AND tent_type = ? AND bed_configuration = ? AND reservation_source = ?");
    $stmt->execute([$current_version['id'], $tent_type, $bed_configuration, $reservation_source]);
    $tent_price = $stmt->fetch();
    
    if (!$tent_price) {
        return ['adult_price' => 0, 'kids_price' => 0, 'total_price' => 0];
    }
    
    $price_per_night = $tent_price['price_per_night'];
    
    // Get kids discount percentage
    $stmt = $pdo->prepare("SELECT discount_percentage FROM kids_discount_percentage WHERE tariff_version_id = ?");
    $stmt->execute([$current_version['id']]);
    $kids_discount = $stmt->fetch();
    $discount_percentage = $kids_discount ? $kids_discount['discount_percentage'] : 50;
    
    // Calculate total tent price for all nights
    $total_tent_price = $price_per_night * $nights;
    
    // Calculate price per person (divide by bed configuration capacity)
    $bed_capacity = getBedCapacity($bed_configuration);
    $price_per_person = $total_tent_price / $bed_capacity;
    
    // Calculate adult and kids prices using the correct logic
    $adult_count = $bed_capacity - $kids_number;
    
    // Ensure we don't have more kids than bed capacity
    if ($kids_number > $bed_capacity) {
        $kids_number = $bed_capacity;
        $adult_count = 0;
    }
    
    $adult_price = $price_per_person * $adult_count; // Full price for adults
    
    $kids_price_per_person = $price_per_person * (1 - ($discount_percentage / 100)); // Discounted price for kids
    $kids_price = $kids_price_per_person * $kids_number;
    
    $total_price = $adult_price + $kids_price;
    
    return [
        'adult_price' => round($adult_price, 2),
        'kids_price' => round($kids_price, 2),
        'total_price' => round($total_price, 2),
        'discount_percentage' => $discount_percentage,
        'price_per_person' => round($price_per_person, 2),
        'kids_price_per_person' => round($kids_price_per_person, 2)
    ];
}



/**
 * Get kids discount percentage for current tariff version
 * @param PDO $pdo Database connection
 * @return int Discount percentage
 */
function getKidsDiscountPercentage($pdo) {
    $stmt = $pdo->query("SELECT id FROM tariff_versions WHERE is_active = 1");
    $current_version = $stmt->fetch();
    
    if (!$current_version) {
        return 50; // Default discount
    }
    
    $stmt = $pdo->prepare("SELECT discount_percentage FROM kids_discount_percentage WHERE tariff_version_id = ?");
    $stmt->execute([$current_version['id']]);
    $kids_discount = $stmt->fetch();
    
    return $kids_discount ? $kids_discount['discount_percentage'] : 50;
}
?> 